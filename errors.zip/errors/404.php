<section class="empty-state">
    <h1>Không tìm thấy trang</h1>
    <p>Đường dẫn bạn yêu cầu không tồn tại hoặc đã được thay đổi.</p>
    <a class="btn btn-primary" href="<?= e(url('home', 'index')) ?>">Về trang chủ</a>
</section>
