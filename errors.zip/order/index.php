<section class="container section">
    <div class="section-heading">
        <div>
            <p class="eyebrow">Tài khoản</p>
            <h1>Đơn hàng của tôi</h1>
        </div>
    </div>

    <?php if (empty($orders)): ?>
        <div class="empty-state">
            <div class="empty-icon-wrap" style="margin-bottom:16px;color:var(--primary);"><?= icon('package', '', 56) ?></div>
            <h2>Bạn chưa có đơn hàng</h2>
            <p>Thực đơn đang chờ bạn chọn món đầu tiên.</p>
            <a class="btn btn-primary" href="<?= e(url('home', 'index')) ?>#menu">Đặt pizza ngay</a>
        </div>
    <?php else: ?>
        <div class="table-wrap">
            <table class="data-table">
                <thead>
                <tr>
                    <th>Mã đơn</th>
                    <th>Ngày đặt</th>
                    <th>Tổng tiền</th>
                    <th>Trạng thái</th>
                    <th>Thanh toán</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><strong>#<?= e($order['id']) ?></strong></td>
                        <td><?= e(date('d/m/Y H:i', strtotime($order['created_at']))) ?></td>
                        <td><strong><?= money($order['total_amount']) ?></strong></td>
                        <td><span class="status"><?= e(order_status_text($order['status'])) ?></span></td>
                        <td><?= e(payment_status_text($order['payment_status'])) ?></td>
                        <td><a class="btn btn-small btn-outline" href="<?= e(url('order', 'detail', ['id' => $order['id']])) ?>">Chi tiết</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
