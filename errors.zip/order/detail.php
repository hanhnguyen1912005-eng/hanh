<section class="container section">
    <div class="section-heading">
        <div>
            <p class="eyebrow">Đơn hàng #<?= e($order['id']) ?></p>
            <h1>Chi tiết đơn hàng</h1>
        </div>
        <a class="btn btn-outline" href="<?= e(is_admin() ? url('admin', 'orders') : url('order', 'index')) ?>">← Quay lại</a>
    </div>

    <!-- KHUNG QUÉT MÃ QR CHO ĐƠN CHUYỂN KHOẢN / MOMO CHƯA THANH TOÁN -->
    <?php if (in_array($order['payment_method'], ['bank', 'momo'], true)): ?>
        <?php if ($order['payment_status'] === 'paid'): ?>
            <div class="order-paid-banner">
                <span class="paid-icon"><?= icon('check-circle', '', 20) ?></span>
                <div>
                    <strong>Đơn hàng đã thanh toán thành công!</strong>
                    <p>Cảm ơn bạn đã thanh toán qua <?= e(payment_method_text($order['payment_method'])) ?>. Pizza House đang chuẩn bị món nóng cho bạn.</p>
                </div>
            </div>
        <?php else: ?>
            <div class="order-qr-payment-panel">
                <div class="order-qr-header">
                    <div>
                        <p class="eyebrow"><?= $order['payment_method'] === 'momo' ? icon('wallet', '', 16) . ' Thanh toán MoMo' : icon('bank', '', 16) . ' Chuyển khoản ngân hàng' ?></p>
                        <h2>Quét mã QR để thanh toán đơn hàng #<?= e($order['id']) ?></h2>
                        <p style="margin:4px 0 0;color:var(--muted);font-size:14px;">Đơn hàng của bạn đã được tiếp nhận. Vui lòng quét mã bên dưới để hoàn tất chuyển tiền.</p>
                    </div>
                    <span class="status" style="background:var(--amber-bg);color:var(--amber);font-weight:800;padding:6px 14px;">Chờ thanh toán</span>
                </div>

                <div class="order-qr-content">
                    <div class="order-qr-img-box">
                        <img src="qr-code/qr.png" alt="Mã QR thanh toán đơn hàng #<?= e($order['id']) ?>" class="qr-img-large">
                        <span class="qr-scan-badge">Quét mã VietQR / MoMo</span>
                    </div>

                    <div class="order-qr-details">
                        <div class="qr-info-row">
                            <span>Phương thức thanh toán:</span>
                            <strong><?= e(payment_method_text($order['payment_method'])) ?></strong>
                        </div>
                        <div class="qr-info-row">
                            <span><?= $order['payment_method'] === 'momo' ? 'Số điện thoại MoMo:' : 'Số tài khoản MB Bank:' ?></span>
                            <div>
                                <strong id="accNum">0909000888</strong>
                                <button type="button" class="btn-copy" onclick="copyOrderDetail('0909000888')">Sao chép</button>
                            </div>
                        </div>
                        <div class="qr-info-row">
                            <span>Tên người thụ hưởng:</span>
                            <strong>PIZZA HOUSE VIETNAM</strong>
                        </div>
                        <div class="qr-info-row">
                            <span>Số tiền cần chuyển:</span>
                            <strong class="qr-highlight-amount"><?= money($order['total_amount']) ?></strong>
                        </div>
                        <div class="qr-info-row">
                            <span>Nội dung chuyển khoản:</span>
                            <div>
                                <strong class="qr-note-highlight" id="transferNote">PIZZA <?= e($order['id']) ?> <?= e($order['customer_phone']) ?></strong>
                                <button type="button" class="btn-copy" onclick="copyOrderDetail('PIZZA <?= e($order['id']) ?> <?= e($order['customer_phone']) ?>')">Sao chép</button>
                            </div>
                        </div>
                        <p class="qr-instruction-text" style="margin-top:14px;">
                            <?= icon('alert', 'text-amber', 16) ?> <strong>Lưu ý:</strong> Vui lòng giữ đúng nội dung chuyển khoản để hệ thống tự động xác nhận đơn hàng nhanh nhất. Sau khi chuyển tiền, đơn sẽ được nhà bếp xử lý và giao hàng ngay!
                        </p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <div class="detail-grid">
        <div class="summary-panel">
            <p class="eyebrow">Giao hàng</p>
            <h2>Thông tin nhận hàng</h2>
            <p style="margin-top:16px;"><strong><?= e($order['customer_name']) ?></strong></p>
            <p><?= e($order['customer_phone']) ?></p>
            <p><?= e($order['customer_email']) ?></p>
            <p><?= e($order['customer_address']) ?></p>
            <?php if ($order['note']): ?>
                <p><strong>Ghi chú:</strong> <?= e($order['note']) ?></p>
            <?php endif; ?>
        </div>

        <div class="summary-panel">
            <p class="eyebrow">Trạng thái</p>
            <h2>Thông tin đơn</h2>
            <div style="margin-top:16px;display:flex;flex-direction:column;gap:10px;">
                <div style="display:flex;justify-content:space-between;">
                    <span style="color:var(--muted);font-weight:600;">Đơn hàng</span>
                    <span class="status"><?= e(order_status_text($order['status'])) ?></span>
                </div>
                <div style="display:flex;justify-content:space-between;">
                    <span style="color:var(--muted);font-weight:600;">Thanh toán</span>
                    <strong><?= e(payment_status_text($order['payment_status'])) ?></strong>
                </div>
                <div style="display:flex;justify-content:space-between;">
                    <span style="color:var(--muted);font-weight:600;">Phương thức</span>
                    <strong><?= e(payment_method_text($order['payment_method'])) ?></strong>
                </div>
                <div style="display:flex;justify-content:space-between;">
                    <span style="color:var(--muted);font-weight:600;">Ngày đặt</span>
                    <span><?= e(date('d/m/Y H:i', strtotime($order['created_at']))) ?></span>
                </div>
            </div>
        </div>
    </div>

    <div class="table-wrap">
        <table class="data-table">
            <thead>
            <tr>
                <th>Sản phẩm</th>
                <th>Kích thước</th>
                <th>Giá</th>
                <th>Số lượng</th>
                <th>Tạm tính</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($items as $item): ?>
                <tr>
                    <td><strong><?= e($item['product_name']) ?></strong></td>
                    <td><span class="badge-size"><?= e(size_label($item['size'] ?? 'M')) ?></span></td>
                    <td><?= money($item['price']) ?></td>
                    <td><?= e($item['quantity']) ?></td>
                    <td><strong><?= money($item['subtotal']) ?></strong></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="order-summary-box-card">
        <?php if (!empty($order['discount_amount']) && (float) $order['discount_amount'] > 0): ?>
            <div class="order-breakdown-row">
                <span>Tạm tính:</span>
                <strong><?= money((float)$order['total_amount'] + (float)$order['discount_amount']) ?></strong>
            </div>
            <div class="order-breakdown-row discount-row">
                <span>Mã giảm giá (<strong><?= e($order['coupon_code']) ?></strong>):</span>
                <strong class="text-danger">-<?= money($order['discount_amount']) ?></strong>
            </div>
        <?php endif; ?>
        <div class="order-breakdown-row order-final-row">
            <span>Tổng thanh toán</span>
            <strong class="cart-highlight-total"><?= money($order['total_amount']) ?></strong>
        </div>
    </div>
</section>

<script>
function copyOrderDetail(text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(() => {
            alert('Đã sao chép nội dung: ' + text);
        }).catch(() => {
            prompt('Sao chép nội dung chuyển khoản:', text);
        });
    } else {
        prompt('Sao chép nội dung chuyển khoản:', text);
    }
}
</script>
