<div class="container section">
    <nav class="breadcrumb">
        <a href="<?= e(url('home', 'index')) ?>">Trang chủ</a> &rsaquo;
        <a href="<?= e(url('home', 'index', ['category_id' => $product['category_id']])) ?>#menu"><?= e($product['category_name'] ?? 'Thực đơn') ?></a> &rsaquo;
        <span><?= e($product['name']) ?></span>
    </nav>

    <!-- CHI TIẾT SẢN PHẨM -->
    <div class="product-detail-card">
        <div class="product-detail-media">
            <img src="<?= e($product['image'] ?: 'img/JTPSD2ONPYISBHIP4CJ5HDW55A_01.webp') ?>" alt="<?= e($product['name']) ?>" class="product-detail-img">
            <span class="pill product-detail-cat"><?= e($product['category_name'] ?? 'Món ngon') ?></span>
        </div>

        <div class="product-detail-info">
            <h1><?= e($product['name']) ?></h1>

            <div class="product-rating-badge-row">
                <a href="#reviews" class="product-rating-pill">
                    <?= icon('star', 'star-icon', 16) ?>
                    <strong><?= number_format($ratingSummary['average'], 1) ?></strong>
                    <span class="rating-count">(<?= $ratingSummary['total'] ?> đánh giá)</span>
                </a>
                <span class="dot-separator">•</span>
                <span class="delivery-badge"><?= icon('flame', '', 14) ?> Phục vụ nóng hổi</span>
            </div>

            <div class="product-price-box">
                <span class="price-amount" id="productDetailPrice"><?= money($product['price']) ?></span>
                <span class="price-unit" id="productDetailUnit">/ phần (Size M)</span>
            </div>

            <!-- BỘ CHỌN KÍCH THƯỚC (S, M, L, XL) -->
            <div class="product-size-section">
                <div class="size-section-header">
                    <label class="size-section-title">Chọn kích thước:</label>
                    <span class="size-selected-desc" id="sizeSelectedDesc">Size M - Vừa (9"): Tiêu chuẩn 2 người</span>
                </div>
                <div class="size-options-pills">
                    <?php
                    $basePrice = (float) $product['price'];
                    $sizesList = [
                        'S' => ['name' => 'Nhỏ (6")', 'desc' => '1 người ăn (80% giá)', 'price' => size_price($basePrice, 'S')],
                        'M' => ['name' => 'Vừa (9")', 'desc' => 'Tiêu chuẩn 2 người', 'price' => size_price($basePrice, 'M')],
                        'L' => ['name' => 'Lớn (12")', 'desc' => '3-4 người ăn (+30%)', 'price' => size_price($basePrice, 'L')],
                        'XL' => ['name' => 'Đại (14")', 'desc' => 'Gia đình / Tiệc (+60%)', 'price' => size_price($basePrice, 'XL')],
                    ];
                    ?>
                    <?php foreach ($sizesList as $sKey => $sInfo): ?>
                        <button type="button" 
                                class="size-pill-btn <?= $sKey === 'M' ? 'active' : '' ?>" 
                                data-size="<?= $sKey ?>" 
                                data-price="<?= $sInfo['price'] ?>" 
                                data-formatted="<?= money($sInfo['price']) ?>"
                                data-desc="Size <?= $sKey ?> - <?= e($sInfo['name']) ?>: <?= e($sInfo['desc']) ?>">
                            <span class="size-pill-code"><?= $sKey ?></span>
                            <span class="size-pill-name"><?= e($sInfo['name']) ?></span>
                            <span class="size-pill-price"><?= money($sInfo['price']) ?></span>
                        </button>
                    <?php endforeach; ?>
                </div>
            </div>

            <p class="product-desc-full"><?= e($product['description']) ?></p>

            <form method="post" action="<?= e(url('cart', 'add')) ?>" class="product-add-cart-form">
                <input type="hidden" name="product_id" value="<?= e($product['id']) ?>">
                <input type="hidden" name="size" id="selectedSizeInput" value="M">
                <div class="qty-stepper">
                    <button type="button" class="stepper-btn" onclick="let q=this.parentElement.querySelector('input'); if(q.value>1) q.value--;">&minus;</button>
                    <input type="number" name="quantity" value="1" min="1" max="20" class="stepper-input">
                    <button type="button" class="stepper-btn" onclick="let q=this.parentElement.querySelector('input'); if(q.value<20) q.value++;">&plus;</button>
                </div>
                <button type="submit" class="btn btn-primary btn-add-cart">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
                    Thêm vào giỏ hàng
                </button>
            </form>

            <div class="product-features-row">
                <div class="feature-item">
                    <span class="feature-icon-svg"><?= icon('truck', '', 18) ?></span>
                    <span>Giao nhanh 30 phút</span>
                </div>
                <div class="feature-item">
                    <span class="feature-icon-svg"><?= icon('soup', '', 18) ?></span>
                    <span>Đóng gói giữ nhiệt</span>
                </div>
                <div class="feature-item">
                    <span class="feature-icon-svg"><?= icon('leaf', '', 18) ?></span>
                    <span>100% Tươi ngon</span>
                </div>
            </div>
        </div>
    </div>

    <!-- PHẦN ĐÁNH GIÁ SẢN PHẨM & PHẢN HỒI -->
    <div id="reviews" class="reviews-section">
        <div class="section-heading">
            <div>
                <p class="eyebrow"><?= icon('star', 'eyebrow-icon', 15) ?> Khách hàng nhận xét</p>
                <h2>Đánh giá & Phản hồi</h2>
            </div>
            <a href="#write-review" class="btn btn-primary btn-small">+ Viết đánh giá</a>
        </div>

        <div class="rating-overview-grid">
            <!-- Điểm trung bình -->
            <div class="rating-score-box">
                <div class="score-large"><?= number_format($ratingSummary['average'], 1) ?></div>
                <div class="stars-display">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <span class="star <?= $i <= round($ratingSummary['average']) ? 'active' : '' ?>"><?= icon('star', '', 18) ?></span>
                    <?php endfor; ?>
                </div>
                <p class="score-sub">Dựa trên <strong><?= $ratingSummary['total'] ?></strong> lượt đánh giá</p>
            </div>

            <!-- Thanh tỷ lệ số sao -->
            <div class="rating-bars-box">
                <?php for ($i = 5; $i >= 1; $i--): ?>
                    <?php $b = $ratingSummary['breakdown'][$i]; ?>
                    <div class="rating-bar-row">
                        <span class="bar-label"><?= $i ?> <?= icon('star', 'bar-star-icon', 12) ?></span>
                        <div class="bar-track">
                            <div class="bar-fill" style="width: <?= $b['percent'] ?>%;"></div>
                        </div>
                        <span class="bar-count"><?= $b['count'] ?> (<?= $b['percent'] ?>%)</span>
                    </div>
                <?php endfor; ?>
            </div>
        </div>

        <!-- FORM VIẾT ĐÁNH GIÁ -->
        <div id="write-review" class="review-form-card">
            <h3>Đánh giá món ăn này</h3>
            <p class="form-sub">Bạn thấy món ăn này thế nào? Hãy chia sẻ trải nghiệm để quán ngày một hoàn thiện hơn nhé!</p>

            <form method="post" action="<?= e(url('product', 'addReview')) ?>">
                <input type="hidden" name="product_id" value="<?= e($product['id']) ?>">
                
                <div class="form-group">
                    <label class="label-star-select">Chọn số sao đánh giá:</label>
                    <div class="star-rating-picker" id="starPicker">
                        <input type="hidden" name="rating" id="ratingInput" value="5">
                        <span class="picker-star active" data-val="1"><?= icon('star', '', 22) ?></span>
                        <span class="picker-star active" data-val="2"><?= icon('star', '', 22) ?></span>
                        <span class="picker-star active" data-val="3"><?= icon('star', '', 22) ?></span>
                        <span class="picker-star active" data-val="4"><?= icon('star', '', 22) ?></span>
                        <span class="picker-star active" data-val="5"><?= icon('star', '', 22) ?></span>
                        <span class="rating-text-hint" id="ratingTextHint">Rất ngon, tuyệt vời! (5/5)</span>
                    </div>
                </div>

                <div class="form-row-grid">
                    <div class="form-group">
                        <label for="customer_name">Họ và tên của bạn:</label>
                        <input type="text" id="customer_name" name="customer_name" required placeholder="Nhập tên của bạn"
                               value="<?= e(current_user()['name'] ?? '') ?>" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="customer_email">Email (tùy chọn):</label>
                        <input type="email" id="customer_email" name="customer_email" placeholder="example@email.com"
                               value="<?= e(current_user()['email'] ?? '') ?>" class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <label for="review_comment">Nội dung đánh giá:</label>
                    <textarea id="review_comment" name="comment" rows="3" required class="form-control"
                              placeholder="Món ăn có hợp khẩu vị bạn không? Độ nóng, nước súp/nước sốt thế nào?..."></textarea>
                </div>

                <button type="submit" class="btn btn-primary"><span>Gửi đánh giá ngay</span> <?= icon('star', '', 16) ?></button>
            </form>
        </div>

        <!-- DANH SÁCH ĐÁNH GIÁ & PHẢN HỒI -->
        <div class="review-list">
            <?php if (empty($reviews)): ?>
                <div class="empty-state compact">
                    <div class="empty-icon-box" style="margin-bottom:12px;"><?= icon('soup', '', 40) ?></div>
                    <h3>Chưa có đánh giá nào cho món này</h3>
                    <p>Hãy là người đầu tiên thưởng thức và chia sẻ cảm nhận về món <?= e($product['name']) ?> nhé!</p>
                </div>
            <?php else: ?>
                <?php foreach ($reviews as $review): ?>
                    <div class="review-card" id="review-<?= e($review['id']) ?>">
                        <div class="review-header">
                            <div class="review-user-info">
                                <div class="user-avatar-circle">
                                    <?= mb_strtoupper(mb_substr($review['customer_name'] ?: 'K', 0, 1, 'UTF-8'), 'UTF-8') ?>
                                </div>
                                <div>
                                    <div class="review-author-name">
                                        <strong><?= e($review['customer_name']) ?></strong>
                                        <span class="verified-badge"><?= icon('check', '', 12) ?> Đã thưởng thức</span>
                                    </div>
                                    <div class="review-meta">
                                        <span class="review-stars-static">
                                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                                <span class="star <?= $i <= (int) $review['rating'] ? 'active' : '' ?>"><?= icon('star', '', 13) ?></span>
                                            <?php endfor; ?>
                                        </span>
                                        <span class="review-date"><?= date('d/m/Y H:i', strtotime($review['created_at'])) ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="review-body">
                            <p><?= nl2br(e($review['comment'])) ?></p>
                        </div>

                        <!-- PHẢN HỒI TỪ QUÁN (STORE / ADMIN REPLY) -->
                        <?php if (!empty($review['admin_reply'])): ?>
                            <div class="store-reply-block">
                                <div class="store-reply-header">
                                    <div class="store-reply-badge">
                                        <span class="store-reply-icon"><?= icon('message', '', 16) ?></span>
                                        <strong>Phản hồi từ Pizza House</strong>
                                    </div>
                                    <span class="store-reply-date">
                                        <?= date('d/m/Y H:i', strtotime($review['admin_replied_at'] ?? $review['created_at'])) ?>
                                    </span>
                                </div>
                                <div class="store-reply-content">
                                    <?= nl2br(e($review['admin_reply'])) ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <!-- NẾU LÀ ADMIN: CÓ THỂ PHẢN HỒI HOẶC SỬA PHẢN HỒI TRỰC TIẾP -->
                        <?php if (is_admin()): ?>
                            <details class="admin-reply-details">
                                <summary class="admin-reply-toggle">
                                    <?= icon('edit', '', 14) ?> <span><?= !empty($review['admin_reply']) ? 'Sửa phản hồi của quán' : 'Phản hồi đánh giá này (Admin)' ?></span>
                                </summary>
                                <form method="post" action="<?= e(url('product', 'replyReview')) ?>" class="admin-inline-reply-form">
                                    <input type="hidden" name="review_id" value="<?= e($review['id']) ?>">
                                    <input type="hidden" name="product_id" value="<?= e($product['id']) ?>">
                                    <div class="form-group">
                                        <textarea name="admin_reply" rows="2" class="form-control" placeholder="Nhập câu trả lời từ quán gửi đến khách hàng..."><?= e($review['admin_reply'] ?? '') ?></textarea>
                                    </div>
                                    <div class="admin-reply-actions">
                                        <button type="submit" class="btn btn-dark btn-small">Lưu phản hồi</button>
                                        <?php if (!empty($review['admin_reply'])): ?>
                                            <span class="hint-text">(Xóa trắng nội dung và lưu để hủy phản hồi)</span>
                                        <?php endif; ?>
                                    </div>
                                </form>
                            </details>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- CÁC MÓN LIÊN QUAN -->
    <?php if (!empty($relatedProducts)): ?>
        <div class="related-section">
            <div class="section-heading">
                <div>
                    <p class="eyebrow">Hương vị tương tự</p>
                    <h2>Món cùng danh mục</h2>
                </div>
            </div>
            <div class="product-grid">
                <?php foreach ($relatedProducts as $rel): ?>
                    <article class="product-card">
                        <a href="<?= e(url('product', 'detail', ['id' => $rel['id']])) ?>" class="product-card-thumb-link">
                            <img src="<?= e($rel['image'] ?: 'img/JTPSD2ONPYISBHIP4CJ5HDW55A_01.webp') ?>" alt="<?= e($rel['name']) ?>" loading="lazy">
                        </a>
                        <div class="product-body">
                            <div class="product-card-top-row">
                                <span class="pill"><?= e($rel['category_name'] ?? 'Món ngon') ?></span>
                            </div>
                            <h3><a href="<?= e(url('product', 'detail', ['id' => $rel['id']])) ?>"><?= e($rel['name']) ?></a></h3>
                            <p><?= e($rel['description']) ?></p>
                            <div class="product-footer">
                                <div class="product-price-box">
                                    <span class="price-sublabel">Giá chỉ</span>
                                    <strong class="product-price"><?= money($rel['price']) ?></strong>
                                </div>
                                <a class="btn btn-primary btn-add-cart" href="<?= e(url('product', 'detail', ['id' => $rel['id']])) ?>">Chi tiết &rsaquo;</a>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const picker = document.getElementById('starPicker');
    if (!picker) return;

    const stars = picker.querySelectorAll('.picker-star');
    const input = document.getElementById('ratingInput');
    const hint = document.getElementById('ratingTextHint');

    const hints = {
        1: 'Không hài lòng (1/5)',
        2: 'Tạm được (2/5)',
        3: 'Bình thường (3/5)',
        4: 'Ngon, hài lòng (4/5)',
        5: 'Rất ngon, tuyệt vời! (5/5)'
    };

    function highlightStars(val) {
        stars.forEach(s => {
            const sVal = parseInt(s.getAttribute('data-val'), 10);
            s.classList.toggle('active', sVal <= val);
        });
        if (hint && hints[val]) {
            hint.textContent = hints[val];
        }
    }

    stars.forEach(s => {
        s.addEventListener('mouseenter', function () {
            const val = parseInt(this.getAttribute('data-val'), 10);
            highlightStars(val);
        });

        s.addEventListener('click', function () {
            const val = parseInt(this.getAttribute('data-val'), 10);
            input.value = val;
            highlightStars(val);
        });
    });

    picker.addEventListener('mouseleave', function () {
        const currentVal = parseInt(input.value, 10) || 5;
        highlightStars(currentVal);
    });

    // BỘ CHỌN KÍCH THƯỚC (SIZE SELECTION)
    const sizePills = document.querySelectorAll('.size-pill-btn');
    const sizeInput = document.getElementById('selectedSizeInput');
    const priceDisplay = document.getElementById('productDetailPrice');
    const unitDisplay = document.getElementById('productDetailUnit');
    const descDisplay = document.getElementById('sizeSelectedDesc');

    sizePills.forEach(btn => {
        btn.addEventListener('click', function () {
            sizePills.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            const sz = this.getAttribute('data-size');
            const formattedPrice = this.getAttribute('data-formatted');
            const desc = this.getAttribute('data-desc');

            if (sizeInput) sizeInput.value = sz;
            if (priceDisplay && formattedPrice) priceDisplay.textContent = formattedPrice;
            if (unitDisplay) unitDisplay.textContent = '/ phần (Size ' + sz + ')';
            if (descDisplay && desc) descDisplay.textContent = desc;
        });
    });
});
</script>
