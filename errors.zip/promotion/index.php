<section class="container section">
    <div class="promo-page-hero">
        <div class="promo-page-hero-content">
            <p class="eyebrow"><?= icon('flame', 'eyebrow-icon', 18) ?> Ưu Đãi Độc Quyền Tại Pizza House</p>
            <h1>Khuyến Mãi & Combo Tiệc Hấp Dẫn</h1>
            <p>Thưởng thức các combo pizza, gà rán giòn rụm, burger và mì Ý chuẩn vị với mức giá ưu đãi cực sốc. Đặt hàng ngay để được giao nóng hổi tận nhà!</p>
        </div>
    </div>

    <?php if (empty($promotions)): ?>
        <div class="empty-state compact">
            <h3>Hiện chưa có khuyến mãi mới</h3>
            <p>Hãy quay lại sau hoặc khám phá thực đơn thường của Pizza House.</p>
            <a class="btn btn-primary" href="<?= e(url('home', 'index')) ?>#menu">Xem thực đơn</a>
        </div>
    <?php else: ?>
        <div class="promo-deals-grid">
            <?php foreach ($promotions as $promo): ?>
                <article class="promo-deal-card">
                    <div class="promo-deal-thumb">
                        <img src="<?= e($promo['image'] ?: 'img/khuyenmai1.webp') ?>" alt="<?= e($promo['name']) ?>" loading="lazy">
                        <span class="promo-discount-badge"><?= icon('zap', '', 13) ?> DEAL HOT</span>
                    </div>
                    <div class="promo-deal-body">
                        <div class="promo-deal-info">
                            <span class="pill"><?= e($promo['category_name'] ?? 'Combo Khuyến Mãi') ?></span>
                            <h3><?= e($promo['name']) ?></h3>
                            <p><?= e($promo['description']) ?></p>
                        </div>
                        <div class="promo-deal-bottom">
                            <div class="promo-deal-price">
                                <span>Giá ưu đãi</span>
                                <strong><?= money($promo['price']) ?></strong>
                            </div>
                            <form method="post" action="<?= e(url('cart', 'add')) ?>" class="promo-add-form">
                                <input type="hidden" name="product_id" value="<?= e($promo['id']) ?>">
                                <input class="qty-input" type="number" name="quantity" value="1" min="1" max="20" aria-label="Số lượng">
                                <button class="btn btn-primary" type="submit">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:4px;"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
                                    Đặt ngay
                                </button>
                            </form>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="promo-menu-callout">
        <div>
            <p class="eyebrow">Thực đơn phong phú</p>
            <h2>Vẫn còn nhiều món ngon đang chờ bạn</h2>
            <p>Khám phá thêm các loại Pizza thơm lừng, Gà rán giòn rụm, Mì Ý sốt bò bằm và Đồ uống mát lạnh.</p>
        </div>
        <a class="btn btn-dark" href="<?= e(url('home', 'index')) ?>#menu">Xem toàn bộ thực đơn →</a>
    </div>
</section>
