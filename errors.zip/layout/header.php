<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle ?? 'Pizza House') ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&family=Playfair+Display:wght@700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css?v=<?= file_exists('assets/css/style.css') ? filemtime('assets/css/style.css') : time() ?>">
    <script>
        (function() {
            const savedTheme = localStorage.getItem('pizzahouse_theme');
            const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
            if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
                document.documentElement.setAttribute('data-theme', 'dark');
            } else {
                document.documentElement.setAttribute('data-theme', 'light');
            }
        })();
    </script>
</head>
<body>
<?php
$currentController = $_GET['controller'] ?? 'home';
?>
<div class="top-announcement-bar">
    <div class="container top-bar-inner">
        <div class="top-bar-left">
            <span class="top-bar-item"><?= icon('truck', '', 14) ?> Giao hàng miễn phí đơn từ 150.000đ</span>
            <span class="top-bar-sep">•</span>
            <span class="top-bar-item"><?= icon('clock', '', 14) ?> Cam kết giao nóng trong 30 phút</span>
        </div>
        <div class="top-bar-right">
            <span class="top-bar-hotline"><?= icon('flame', '', 14) ?> Hotline đặt món: <strong>0909 000 888</strong></span>
        </div>
    </div>
</div>

<header class="site-header">
    <div class="container nav-wrap">
        <a class="brand" href="<?= e(url('home', 'index')) ?>">
            <span class="brand-mark"><?= icon('pizza', 'brand-icon', 22) ?></span>
            <span>Pizza House</span>
        </a>

        <nav class="main-nav">
            <a href="<?= e(url('home', 'index')) ?>" class="<?= $currentController === 'home' ? 'active' : '' ?>">Trang chủ</a>
            <a href="<?= e(url('promotion', 'index')) ?>" class="<?= $currentController === 'promotion' ? 'active' : '' ?>">Khuyến mãi</a>
            <a href="<?= e(url('support', 'index')) ?>" class="<?= $currentController === 'support' ? 'active' : '' ?>">CSKH</a>
            <a href="<?= e(url('cart', 'index')) ?>" class="nav-cart-link <?= $currentController === 'cart' ? 'active' : '' ?>">
                <?= icon('cart', '', 17) ?>
                <span>Giỏ hàng</span>
                <span class="badge <?= cart_count() > 0 ? 'badge-pulse' : '' ?>"><?= cart_count() ?></span>
            </a>
            <?php if (is_logged_in()): ?>
                <a href="<?= e(url('order', 'index')) ?>" class="<?= $currentController === 'order' ? 'active' : '' ?>">Đơn hàng</a>
            <?php endif; ?>
            <?php if (is_admin()): ?>
                <a href="<?= e(url('admin', 'dashboard')) ?>" class="<?= $currentController === 'admin' ? 'active' : '' ?>">Admin</a>
            <?php endif; ?>
        </nav>

        <div class="account-nav">
            <button type="button" class="theme-toggle-btn" id="themeToggleBtn" aria-label="Chuyển chế độ sáng/tối" title="Chuyển đổi giao diện Sáng / Tối">
                <span class="theme-icon-light"><?= icon('sun', '', 18) ?></span>
                <span class="theme-icon-dark"><?= icon('moon', '', 18) ?></span>
            </button>
            <?php if (is_logged_in()): ?>
                <span class="hello">Xin chào, <?= e(current_user()['name']) ?></span>
                <a class="btn btn-outline btn-small" href="<?= e(url('auth', 'logout')) ?>">Đăng xuất</a>
            <?php else: ?>
                <a class="btn btn-ghost btn-small <?= $currentController === 'auth' && ($_GET['action'] ?? '') === 'login' ? 'active' : '' ?>" href="<?= e(url('auth', 'login')) ?>">Đăng nhập</a>
                <a class="btn btn-primary btn-small" href="<?= e(url('auth', 'register')) ?>">Đăng ký</a>
            <?php endif; ?>
        </div>
    </div>
</header>

<main>
    <div class="container">
        <?php foreach (consume_flash() as $type => $messages): ?>
            <?php foreach ($messages as $message): ?>
                <div class="alert alert-<?= e($type) ?>"><?= e($message) ?></div>
            <?php endforeach; ?>
        <?php endforeach; ?>
    </div>
