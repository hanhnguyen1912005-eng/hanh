</main>

    <!-- FLOATING QUICK CART & BACK TO TOP WIDGETS -->
    <div class="floating-actions-wrap">
        <?php if (cart_count() > 0): ?>
            <a href="<?= e(url('cart', 'index')) ?>" class="floating-cart-btn" id="floatingCartBtn" title="Xem giỏ hàng (<?= cart_count() ?> món)">
                <span class="floating-cart-icon-box">
                    <?= icon('cart', '', 20) ?>
                    <span class="floating-cart-badge"><?= cart_count() ?></span>
                </span>
                <span class="floating-cart-text">Giỏ hàng (<?= cart_count() ?>)</span>
            </a>
        <?php endif; ?>

        <button type="button" class="back-to-top-btn" id="backToTopBtn" aria-label="Lên đầu trang" onclick="window.scrollTo({top: 0, behavior: 'smooth'})">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"></polyline></svg>
        </button>
    </div>

    <footer class="site-footer">
        <div class="container footer-grid">
            <!-- Cột 1: Thương hiệu -->
            <div class="footer-brand-col">
                <a class="brand footer-brand" href="<?= e(url('home', 'index')) ?>">
                    <span class="brand-mark"><?= icon('pizza', 'brand-icon', 22) ?></span>
                    <span>Pizza House</span>
                </a>
                <p class="footer-desc">Thương hiệu pizza truyền thống chuẩn vị Ý nướng lò đá thơm lừng, gà rán vàng giòn và mì hảo hạng với 100% phô mai Mozzarella tươi nhập khẩu.</p>
                <div class="footer-usp-pills">
                    <span class="footer-mini-pill"><?= icon('sparkle', '', 12) ?> 100% Tươi ngon</span>
                    <span class="footer-mini-pill"><?= icon('truck', '', 12) ?> Giao nhanh 30m</span>
                </div>
            </div>

            <!-- Cột 2: Thực đơn phổ biến -->
            <div class="footer-col">
                <h4 class="footer-heading">Món ngon nổi bật</h4>
                <ul class="footer-links">
                    <li><a href="<?= e(url('home', 'index')) ?>#menu">Pizza Hải Sản Pesto</a></li>
                    <li><a href="<?= e(url('home', 'index')) ?>#menu">Pizza Bò Nướng Xốt BBQ</a></li>
                    <li><a href="<?= e(url('home', 'index')) ?>#menu">Gà Rán Giòn Rụm Sốt Cay</a></li>
                    <li><a href="<?= e(url('home', 'index')) ?>#menu">Mì Ý Sốt Bò Bằm Phô Mai</a></li>
                    <li><a href="<?= e(url('home', 'index')) ?>#menu">Mì Trộn & Mì Nước Cay Kim Chi</a></li>
                </ul>
            </div>

            <!-- Cột 3: Hỗ trợ & CSKH -->
            <div class="footer-col">
                <h4 class="footer-heading">Chăm sóc khách hàng</h4>
                <ul class="footer-links">
                    <li><a href="<?= e(url('support', 'index')) ?>">Gửi yêu cầu hỗ trợ</a></li>
                    <li><a href="<?= e(url('promotion', 'index')) ?>">Chương trình khuyến mãi</a></li>
                    <?php if (is_logged_in()): ?>
                        <li><a href="<?= e(url('order', 'index')) ?>">Tra cứu đơn hàng của tôi</a></li>
                    <?php else: ?>
                        <li><a href="<?= e(url('auth', 'login')) ?>">Đăng nhập tài khoản</a></li>
                    <?php endif; ?>
                    <li><a href="<?= e(url('support', 'index')) ?>">Chính sách giao nhận & hoàn tiền</a></li>
                </ul>
            </div>

            <!-- Cột 4: Hotline & Giờ mở cửa -->
            <div class="footer-col">
                <h4 class="footer-heading">Liên hệ & Đặt hàng</h4>
                <div class="footer-contact-box">
                    <div class="footer-hotline-row">
                        <?= icon('flame', 'text-primary', 20) ?>
                        <div>
                            <span class="footer-sublabel">Hotline giao hàng</span>
                            <strong class="footer-hotline-num">0909 000 888</strong>
                        </div>
                    </div>
                    <div class="footer-hours-row">
                        <?= icon('clock', 'text-amber', 18) ?>
                        <div>
                            <span class="footer-sublabel">Thời gian phục vụ</span>
                            <strong>08:30 – 22:30 (Cả T7 & CN)</strong>
                        </div>
                    </div>
                    <div class="footer-payments-row">
                        <span class="footer-sublabel">Thanh toán an toàn:</span>
                        <div class="payment-badge-icons">
                            <span class="pay-chip" title="Thanh toán khi nhận hàng"><?= icon('cash', '', 14) ?> COD</span>
                            <span class="pay-chip" title="Chuyển khoản VietQR"><?= icon('bank', '', 14) ?> VietQR</span>
                            <span class="pay-chip" title="Ví điện tử MoMo"><?= icon('wallet', '', 14) ?> MoMo</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer-bottom">
            <div class="container footer-bottom-inner">
                <p>© 2026 Pizza House Vietnam. All rights reserved. Đậm đà phong vị Ý.</p>
                <div class="footer-bottom-links">
                    <span>Quy định bảo mật</span>
                    <span class="dot-sep">•</span>
                    <span>Điều khoản sử dụng</span>
                </div>
            </div>
        </div>
    </footer>

    <script>
    // Xử lý chuyển đổi giao diện Sáng / Tối (Theme Toggle)
    const themeBtn = document.getElementById('themeToggleBtn');
    if (themeBtn) {
        themeBtn.addEventListener('click', function() {
            const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('pizzahouse_theme', newTheme);
        });
    }

    // Xử lý nút cuộn lên đầu trang (Back to Top)
    window.addEventListener('scroll', function() {
        const btn = document.getElementById('backToTopBtn');
        if (!btn) return;
        if (window.pageYOffset > 320) {
            btn.classList.add('is-visible');
        } else {
            btn.classList.remove('is-visible');
        }
    });
    </script>
</body>
</html>
