<?php
$formName    = $_POST['name']    ?? ($user['name']    ?? '');
$formEmail   = $_POST['email']   ?? ($user['email']   ?? '');
$formPhone   = $_POST['phone']   ?? ($user['phone']   ?? '');
$formAddress = $_POST['address'] ?? ($user['address'] ?? '');
$currentMethod = $_POST['payment_method'] ?? 'cod';
?>

<div class="container" style="padding-top:24px;">
    <div class="checkout-steps-bar">
        <a href="<?= e(url('cart', 'index')) ?>" class="step-item completed">
            <span class="step-num"><?= icon('check', '', 14) ?></span>
            <span class="step-label">Giỏ hàng</span>
        </a>
        <div class="step-line active"></div>
        <div class="step-item active">
            <span class="step-num">2</span>
            <span class="step-label">Thanh toán</span>
        </div>
        <div class="step-line"></div>
        <div class="step-item">
            <span class="step-num">3</span>
            <span class="step-label">Hoàn tất</span>
        </div>
    </div>
</div>

<section class="container section checkout-grid" style="padding-top:16px;">
    <form class="form-panel" method="post" action="<?= e(url('checkout', 'index')) ?>">
        <p class="eyebrow"><?= icon('truck', '', 14) ?> Thông tin đặt hàng</p>
        <h1>Thông tin giao hàng</h1>

        <label>Họ tên</label>
        <input type="text" name="name" required value="<?= e($formName) ?>">

        <label>Email</label>
        <input type="email" name="email" value="<?= e($formEmail) ?>">

        <label>Số điện thoại</label>
        <input type="text" name="phone" id="customerPhone" required placeholder="0909 000 888" value="<?= e($formPhone) ?>">

        <label>Địa chỉ giao hàng</label>
        <textarea name="address" rows="3" required><?= e($formAddress) ?></textarea>

        <label>Ghi chú</label>
        <textarea name="note" rows="3" placeholder="Ví dụ: ít phô mai, giao giờ hành chính..."><?= e($_POST['note'] ?? '') ?></textarea>

        <label style="margin-bottom:8px;">Phương thức thanh toán</label>
        <div class="payment-options">
            <label>
                <input type="radio" name="payment_method" value="cod" <?= $currentMethod === 'cod' ? 'checked' : '' ?>>
                <span class="payment-label-wrap"><?= icon('cash', '', 18) ?> Thanh toán khi nhận hàng (COD)</span>
            </label>
            <label>
                <input type="radio" name="payment_method" value="bank" <?= $currentMethod === 'bank' ? 'checked' : '' ?>>
                <span class="payment-label-wrap"><?= icon('bank', '', 18) ?> Chuyển khoản ngân hàng</span>
            </label>
            <label>
                <input type="radio" name="payment_method" value="momo" <?= $currentMethod === 'momo' ? 'checked' : '' ?>>
                <span class="payment-label-wrap"><?= icon('wallet', '', 18) ?> Ví MoMo</span>
            </label>
        </div>

        <!-- KHUNG MÃ QR THANH TOÁN (NGÂN HÀNG & MOMO) -->
        <div id="qrPaymentBox" class="qr-payment-box" style="display: <?= in_array($currentMethod, ['bank', 'momo'], true) ? 'block' : 'none' ?>;">
            <div class="qr-payment-card">
                <div class="qr-image-wrapper">
                    <img src="qr-code/qr.png" alt="Mã QR thanh toán Pizza House" class="qr-img">
                    <span class="qr-scan-badge">Quét mã để trả tiền</span>
                </div>
                
                <!-- THÔNG TIN NGÂN HÀNG -->
                <div class="qr-payment-info" id="qrBankInfo" style="display: <?= $currentMethod === 'bank' ? 'block' : 'none' ?>;">
                    <p class="eyebrow" style="margin-bottom:4px;"><?= icon('bank', '', 16) ?> Chuyển khoản ngân hàng</p>
                    <h4 style="margin:2px 0 10px;font-size:16px;">Ngân hàng Quân Đội (MB Bank)</h4>
                    <div class="qr-info-row">
                        <span>Số tài khoản:</span>
                        <div>
                            <strong id="bankAcc">0909000888</strong>
                            <button type="button" class="btn-copy" onclick="copyValue('0909000888')">Sao chép</button>
                        </div>
                    </div>
                    <div class="qr-info-row">
                        <span>Chủ tài khoản:</span>
                        <strong>PIZZA HOUSE VIETNAM</strong>
                    </div>
                    <div class="qr-info-row">
                        <span>Số tiền thanh toán:</span>
                        <strong class="qr-highlight-amount"><?= money($total) ?></strong>
                    </div>
                    <div class="qr-info-row">
                        <span>Nội dung CK:</span>
                        <div>
                            <strong class="qr-note-highlight" id="bankNoteDisplay">PIZZA <?= e($formPhone ?: 'SĐT') ?></strong>
                            <button type="button" class="btn-copy" onclick="copyValue(document.getElementById('bankNoteDisplay').innerText)">Sao chép</button>
                        </div>
                    </div>
                    <p class="qr-instruction-text"><?= icon('lightbulb', '', 16) ?> Mở app ngân hàng (VietinBank, Vietcombank, MB, Techcombank...) quét mã QR để thanh toán nhanh chóng.</p>
                </div>

                <!-- THÔNG TIN MOMO -->
                <div class="qr-payment-info" id="qrMomoInfo" style="display: <?= $currentMethod === 'momo' ? 'block' : 'none' ?>;">
                    <p class="eyebrow" style="margin-bottom:4px;"><?= icon('wallet', '', 16) ?> Thanh toán Ví MoMo</p>
                    <h4 style="margin:2px 0 10px;font-size:16px;">Ví Điện Tử MoMo</h4>
                    <div class="qr-info-row">
                        <span>Số điện thoại MoMo:</span>
                        <div>
                            <strong id="momoPhone">0909000888</strong>
                            <button type="button" class="btn-copy" onclick="copyValue('0909000888')">Sao chép</button>
                        </div>
                    </div>
                    <div class="qr-info-row">
                        <span>Chủ ví MoMo:</span>
                        <strong>PIZZA HOUSE VIETNAM</strong>
                    </div>
                    <div class="qr-info-row">
                        <span>Số tiền thanh toán:</span>
                        <strong class="qr-highlight-amount"><?= money($total) ?></strong>
                    </div>
                    <div class="qr-info-row">
                        <span>Lời nhắn chuyển tiền:</span>
                        <div>
                            <strong class="qr-note-highlight" id="momoNoteDisplay">PIZZA <?= e($formPhone ?: 'SĐT') ?></strong>
                            <button type="button" class="btn-copy" onclick="copyValue(document.getElementById('momoNoteDisplay').innerText)">Sao chép</button>
                        </div>
                    </div>
                    <p class="qr-instruction-text"><?= icon('lightbulb', '', 16) ?> Mở ứng dụng MoMo, chọn <strong>Quét mã QR</strong> để chuyển tiền tức thì không cần nhập số tài khoản.</p>
                </div>
            </div>
        </div>

        <button class="btn btn-primary full" type="submit" style="margin-top:14px;">Xác nhận đặt hàng →</button>
    </form>

    <aside class="summary-panel">
        <p class="eyebrow">Đơn hàng</p>
        <h2>Tóm tắt món</h2>
        <?php foreach ($items as $item): ?>
            <div class="summary-row">
                <div class="summary-item-info">
                    <span class="summary-item-name"><?= e($item['product']['name']) ?></span>
                    <span class="badge-size-mini"><?= e($item['size_label']) ?></span>
                    <span class="summary-item-qty">x <?= e($item['quantity']) ?></span>
                </div>
                <strong><?= money($item['subtotal']) ?></strong>
            </div>
        <?php endforeach; ?>

        <!-- COUPON TRONG THANH TOÁN -->
        <div class="checkout-coupon-widget">
            <?php if ($coupon): ?>
                <div class="checkout-coupon-applied">
                    <div class="coupon-applied-text">
                        <?= icon('ticket', 'text-primary', 16) ?>
                        <strong><?= e($coupon['code']) ?></strong>
                        <span>(-<?= money($discount) ?>)</span>
                    </div>
                    <a href="<?= e(url('cart', 'removeCoupon', ['from' => 'checkout'])) ?>" class="btn-remove-coupon-mini">Bỏ</a>
                </div>
            <?php else: ?>
                <form method="post" action="<?= e(url('cart', 'applyCoupon')) ?>" class="checkout-coupon-form">
                    <input type="hidden" name="from" value="checkout">
                    <input type="text" name="coupon_code" placeholder="Mã giảm giá..." required>
                    <button type="submit" class="btn btn-dark btn-small">Dùng mã</button>
                </form>
            <?php endif; ?>
        </div>

        <div class="summary-subtotal-row">
            <span>Tạm tính</span>
            <strong><?= money($subtotal) ?></strong>
        </div>

        <?php if ($discount > 0): ?>
            <div class="summary-discount-row">
                <span>Giảm giá (<?= e($coupon['code']) ?>)</span>
                <strong class="text-danger">-<?= money($discount) ?></strong>
            </div>
        <?php endif; ?>

        <div class="summary-total">
            <span>Tổng thanh toán</span>
            <strong class="cart-highlight-total"><?= money($total) ?></strong>
        </div>
    </aside>
</section>

<script>
function copyValue(text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(() => {
            alert('Đã sao chép: ' + text);
        }).catch(() => {
            prompt('Sao chép nội dung:', text);
        });
    } else {
        prompt('Sao chép nội dung:', text);
    }
}

document.addEventListener('DOMContentLoaded', function () {
    const radioMethods = document.querySelectorAll('input[name="payment_method"]');
    const qrBox = document.getElementById('qrPaymentBox');
    const bankInfo = document.getElementById('qrBankInfo');
    const momoInfo = document.getElementById('qrMomoInfo');
    const phoneInput = document.getElementById('customerPhone');
    const bankNoteDisplay = document.getElementById('bankNoteDisplay');
    const momoNoteDisplay = document.getElementById('momoNoteDisplay');

    function updateNoteWithPhone() {
        const phone = (phoneInput && phoneInput.value.trim()) ? phoneInput.value.trim() : 'SĐT';
        const note = 'PIZZA ' + phone;
        if (bankNoteDisplay) bankNoteDisplay.innerText = note;
        if (momoNoteDisplay) momoNoteDisplay.innerText = note;
    }

    if (phoneInput) {
        phoneInput.addEventListener('input', updateNoteWithPhone);
    }

    function toggleQrBox() {
        let selected = 'cod';
        radioMethods.forEach(r => {
            if (r.checked) selected = r.value;
        });

        if (selected === 'bank') {
            qrBox.style.display = 'block';
            bankInfo.style.display = 'block';
            momoInfo.style.display = 'none';
        } else if (selected === 'momo') {
            qrBox.style.display = 'block';
            bankInfo.style.display = 'none';
            momoInfo.style.display = 'block';
        } else {
            qrBox.style.display = 'none';
        }
    }

    radioMethods.forEach(r => {
        r.addEventListener('change', toggleQrBox);
    });

    updateNoteWithPhone();
});
</script>
