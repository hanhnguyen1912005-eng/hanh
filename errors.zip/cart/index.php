<section class="container section">
    <!-- CHECKOUT STEPS PROGRESS BAR -->
    <div class="checkout-steps-bar">
        <div class="step-item active">
            <span class="step-num">1</span>
            <span class="step-label">Giỏ hàng</span>
        </div>
        <div class="step-line"></div>
        <div class="step-item">
            <span class="step-num">2</span>
            <span class="step-label">Thanh toán</span>
        </div>
        <div class="step-line"></div>
        <div class="step-item">
            <span class="step-num">3</span>
            <span class="step-label">Hoàn tất</span>
        </div>
    </div>

    <div class="section-heading">
        <div>
            <p class="eyebrow"><?= icon('cart', '', 14) ?> Giỏ hàng của bạn</p>
            <h1>Pizza & Món đã chọn</h1>
        </div>
        <a class="btn btn-outline" href="<?= e(url('home', 'index')) ?>#menu">← Tiếp tục chọn món</a>
    </div>

    <?php if (empty($items)): ?>
        <div class="empty-state">
            <div class="empty-icon-wrap" style="margin-bottom:16px;color:var(--primary);"><?= icon('cart', '', 56) ?></div>
            <h2>Giỏ hàng đang trống</h2>
            <p>Chọn vài chiếc pizza nóng hổi rồi quay lại đây thanh toán nhé.</p>
            <a class="btn btn-primary" href="<?= e(url('home', 'index')) ?>#menu">Xem thực đơn ngay</a>
        </div>
    <?php else: ?>
        <form method="post" action="<?= e(url('cart', 'update')) ?>">
            <div class="table-wrap">
                <table class="data-table">
                    <thead>
                    <tr>
                        <th>Sản phẩm</th>
                        <th>Kích thước</th>
                        <th>Đơn giá</th>
                        <th>Số lượng</th>
                        <th>Tạm tính</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($items as $item): ?>
                        <?php $product = $item['product']; ?>
                        <tr>
                            <td class="product-cell">
                                <img src="<?= e($product['image'] ?: 'img/JTPSD2ONPYISBHIP4CJ5HDW55A_01.webp') ?>" alt="<?= e($product['name']) ?>">
                                <div>
                                    <strong class="cart-prod-name"><?= e($product['name']) ?></strong>
                                    <span class="cart-prod-desc"><?= e($product['description']) ?></span>
                                </div>
                            </td>
                            <td>
                                <span class="badge-size"><?= e($item['size_label']) ?></span>
                            </td>
                            <td><strong class="cart-price"><?= money($item['price']) ?></strong></td>
                            <td>
                                <input class="qty-input wide" type="number" name="quantities[<?= e($item['key']) ?>]" min="0" max="20" value="<?= e($item['quantity']) ?>">
                            </td>
                            <td><strong class="cart-subtotal"><?= money($item['subtotal']) ?></strong></td>
                            <td>
                                <a class="cart-remove-btn" href="<?= e(url('cart', 'remove', ['key' => $item['key']])) ?>" title="Xóa món này">
                                    <?= icon('trash', '', 16) ?>
                                    <span>Xóa</span>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- KHU VỰC TỔNG KẾT & THANH TOÁN (2-COLUMN GRID) -->
            <div class="cart-bottom-grid">
                <!-- CỘT TRÁI: MÃ GIẢM GIÁ & THAO TÁC GIỎ HÀNG -->
                <div class="cart-bottom-left">
                    <!-- KHUNG ÁP MÃ GIẢM GIÁ (COUPON / VOUCHER) -->
                    <div class="cart-coupon-section">
                        <div class="coupon-input-card">
                            <div class="coupon-header">
                                <?= icon('ticket', 'text-primary', 20) ?>
                                <strong>Mã giảm giá / Voucher ưu đãi</strong>
                            </div>

                            <?php if ($coupon): ?>
                                <div class="coupon-applied-box">
                                    <div class="coupon-applied-info">
                                        <span class="coupon-badge"><?= icon('check-circle', '', 14) ?> <?= e($coupon['code']) ?></span>
                                        <span class="coupon-desc"><?= e($coupon['description'] ?: 'Áp dụng mã giảm giá thành công') ?></span>
                                        <strong class="coupon-discount-text">-<?= money($discount) ?></strong>
                                    </div>
                                    <a href="<?= e(url('cart', 'removeCoupon')) ?>" class="btn-remove-coupon">Bỏ áp dụng</a>
                                </div>
                            <?php else: ?>
                                <div class="coupon-form-wrap">
                                    <div class="coupon-input-wrap">
                                        <?= icon('ticket', 'coupon-icon', 18) ?>
                                        <input type="text" name="coupon_code" id="couponCodeInput" placeholder="Nhập mã ưu đãi (ví dụ: PIZZA20K)...">
                                    </div>
                                    <button type="submit" formaction="<?= e(url('cart', 'applyCoupon')) ?>" class="btn btn-dark btn-apply-coupon">
                                        <?= icon('check', '', 16) ?>
                                        <span>Áp dụng</span>
                                    </button>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($availableCoupons)): ?>
                                <div class="suggested-vouchers">
                                    <span class="suggest-label">Mã ưu đãi có sẵn:</span>
                                    <div class="voucher-chips">
                                        <?php foreach ($availableCoupons as $av): ?>
                                            <button type="button" class="voucher-chip" onclick="let input=document.getElementById('couponCodeInput'); if(input){input.value='<?= e($av['code']) ?>'; input.focus();}" title="<?= e($av['description']) ?>">
                                                <?= icon('tag', '', 13) ?>
                                                <strong><?= e($av['code']) ?></strong>
                                                <span>(<?= $av['discount_type'] === 'percent' ? '-' . (int)$av['discount_value'] . '%' : '-' . money($av['discount_value']) ?>)</span>
                                            </button>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- THANH CÔNG CỤ THAO TÁC GIỎ HÀNG -->
                    <div class="cart-actions-toolbar">
                        <a class="btn btn-outline btn-cart-action" href="<?= e(url('home', 'index')) ?>#menu">
                            <?= icon('arrow-left', '', 14) ?>
                            <span>Tiếp tục chọn món</span>
                        </a>
                        <button class="btn btn-outline btn-cart-action" type="submit">
                            <?= icon('sparkle', '', 14) ?>
                            <span>Cập nhật giỏ</span>
                        </button>
                        <a class="link-danger btn-clear-cart" href="<?= e(url('cart', 'clear')) ?>" onclick="return confirm('Bạn có chắc chắn muốn làm trống giỏ hàng không?');">
                            <?= icon('trash', '', 14) ?>
                            <span>Làm trống giỏ</span>
                        </a>
                    </div>

                    <!-- CAM KẾT CHẤT LƯỢNG -->
                    <div class="cart-perks-row">
                        <div class="cart-perk-item">
                            <span class="perk-icon-wrap"><?= icon('truck', '', 16) ?></span>
                            <span>Giao nóng 30 phút</span>
                        </div>
                        <div class="cart-perk-item">
                            <span class="perk-icon-wrap"><?= icon('shield-check', '', 16) ?></span>
                            <span>Nguyên liệu tươi sạch</span>
                        </div>
                        <div class="cart-perk-item">
                            <span class="perk-icon-wrap"><?= icon('rotate-ccw', '', 16) ?></span>
                            <span>Đổi miễn phí nếu nguội</span>
                        </div>
                    </div>
                </div>

                <!-- CỘT PHẢI: BẢNG TỔNG KẾT HÓA ĐƠN & NÚT THANH TOÁN -->
                <div class="cart-bottom-right">
                    <div class="cart-shipping-perk-box">
                        <?= icon('truck', 'text-green', 20) ?>
                        <span><?= $total >= 150000 ? 'Chúc mừng! Đơn hàng được <strong>Miễn phí giao hàng</strong>.' : 'Mua thêm ' . money(150000 - $total) . ' để nhận <strong>Freeship</strong>!' ?></span>
                    </div>

                    <div class="cart-order-summary-panel">
                        <h3 class="cart-summary-heading">Tóm tắt thanh toán</h3>
                        
                        <div class="cart-bill-rows">
                            <div class="cart-bill-item">
                                <span class="bill-item-label">Tạm tính:</span>
                                <strong class="bill-item-value"><?= money($subtotal) ?></strong>
                            </div>

                            <?php if ($discount > 0): ?>
                                <div class="cart-bill-item discount-item">
                                    <span class="bill-item-label">Giảm giá (<?= e($coupon['code']) ?>):</span>
                                    <strong class="bill-item-value text-discount">-<?= money($discount) ?></strong>
                                </div>
                            <?php endif; ?>

                            <div class="cart-bill-divider"></div>

                            <div class="cart-bill-item total-item">
                                <div>
                                    <span class="bill-total-title">Tổng thanh toán:</span>
                                    <small class="bill-vat-note">(Đã trừ giảm giá)</small>
                                </div>
                                <strong class="cart-highlight-total"><?= money($total) ?></strong>
                            </div>
                        </div>

                        <a class="btn btn-primary btn-checkout-main" href="<?= e(url('checkout', 'index')) ?>">
                            <span>Tiến hành thanh toán</span>
                            <?= icon('arrow-right', '', 18) ?>
                        </a>

                        <div class="cart-payment-badges-row">
                            <?= icon('shield-check', '', 14) ?>
                            <span>Thanh toán an toàn với VietQR, MoMo & COD</span>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    <?php endif; ?>
</section>
