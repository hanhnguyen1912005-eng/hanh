<section class="auth-shell container">
    <div class="auth-visual" style="background-image: linear-gradient(180deg, rgba(30,18,10,.2), rgba(30,18,10,.78)), url('img/PestoE1A3iE1A3n.webp');">
        <h1>Tạo tài khoản<br>mới</h1>
        <p>Lưu thông tin nhận hàng để đặt pizza nhanh hơn trong những lần sau.</p>
    </div>

    <form class="form-panel" method="post" action="<?= e(url('auth', 'register')) ?>">
        <p class="eyebrow">Khách hàng</p>
        <h2>Đăng ký</h2>

        <label>Họ tên</label>
        <input type="text" name="name" required value="<?= e($_POST['name'] ?? '') ?>">

        <label>Email</label>
        <input type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>">

        <label>Mật khẩu</label>
        <input type="password" name="password" required minlength="6" placeholder="Ít nhất 6 ký tự">

        <label>Số điện thoại</label>
        <input type="text" name="phone" placeholder="0909 000 888" value="<?= e($_POST['phone'] ?? '') ?>">

        <label>Địa chỉ</label>
        <textarea name="address" rows="3" placeholder="Địa chỉ giao hàng"><?= e($_POST['address'] ?? '') ?></textarea>

        <button class="btn btn-primary full" type="submit" style="margin-top:22px;">Tạo tài khoản</button>
        <p class="form-note">Đã có tài khoản? <a href="<?= e(url('auth', 'login')) ?>">Đăng nhập</a></p>
    </form>
</section>
