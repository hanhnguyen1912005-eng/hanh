<section class="auth-shell container">
    <div class="auth-visual" style="background-image: linear-gradient(180deg, rgba(30,18,10,.2), rgba(30,18,10,.78)), url('img/JTPSD2ONPYISBHIP4CJ5HDW55A_01.webp');">
        <h1>Chào mừng<br>trở lại!</h1>
        <p>Đăng nhập để thanh toán và theo dõi đơn pizza của bạn.</p>
    </div>

    <form class="form-panel" method="post" action="<?= e(url('auth', 'login')) ?>">
        <p class="eyebrow">Tài khoản</p>
        <h2>Đăng nhập</h2>

        <label>Email</label>
        <input type="email" name="email" required placeholder="you@example.com" value="<?= e($_POST['email'] ?? '') ?>">

        <label>Mật khẩu</label>
        <input type="password" name="password" required placeholder="Nhập mật khẩu">

        <button class="btn btn-primary full" type="submit" style="margin-top:22px;">Đăng nhập</button>
        <p class="form-note">Chưa có tài khoản? <a href="<?= e(url('auth', 'register')) ?>">Đăng ký ngay</a></p>
    </form>
</section>
