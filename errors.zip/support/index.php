<?php
$formName = $_POST['name'] ?? ($user['name'] ?? '');
$formEmail = $_POST['email'] ?? ($user['email'] ?? '');
$formPhone = $_POST['phone'] ?? ($user['phone'] ?? '');
$formOrderId = (int) ($_POST['order_id'] ?? 0);
$formPriority = $_POST['priority'] ?? 'normal';
?>

<section class="container section support-grid">
    <form class="form-panel" method="post" action="<?= e(url('support', 'index')) ?>">
        <p class="eyebrow">Chăm sóc khách hàng</p>
        <h1>Gửi yêu cầu hỗ trợ</h1>

        <label>Họ tên</label>
        <input type="text" name="name" required value="<?= e($formName) ?>">

        <label>Email</label>
        <input type="email" name="email" value="<?= e($formEmail) ?>">

        <label>Số điện thoại</label>
        <input type="text" name="phone" required placeholder="0909 000 888" value="<?= e($formPhone) ?>">

        <?php if (!empty($orders)): ?>
            <label>Đơn hàng liên quan</label>
            <select name="order_id">
                <option value="0">Không gắn đơn hàng</option>
                <?php foreach ($orders as $order): ?>
                    <option value="<?= e($order['id']) ?>" <?= $formOrderId === (int) $order['id'] ? 'selected' : '' ?>>
                        #<?= e($order['id']) ?> - <?= e(date('d/m/Y H:i', strtotime($order['created_at']))) ?> - <?= money($order['total_amount']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        <?php else: ?>
            <label>Mã đơn hàng nếu có</label>
            <input type="number" name="order_id" min="1" value="<?= $formOrderId > 0 ? e($formOrderId) : '' ?>">
        <?php endif; ?>

        <label>Chủ đề</label>
        <input type="text" name="subject" required maxlength="180" placeholder="Ví dụ: cần đổi địa chỉ giao hàng" value="<?= e($_POST['subject'] ?? '') ?>">

        <label>Nội dung</label>
        <textarea name="message" rows="5" required placeholder="Mô tả yêu cầu của bạn..."><?= e($_POST['message'] ?? '') ?></textarea>

        <label style="margin-bottom:4px;">Mức độ</label>
        <div class="payment-options support-priority-options">
            <label>
                <input type="radio" name="priority" value="normal" <?= $formPriority === 'urgent' ? '' : 'checked' ?>>
                <span>Thông thường</span>
            </label>
            <label>
                <input type="radio" name="priority" value="urgent" <?= $formPriority === 'urgent' ? 'checked' : '' ?>>
                <span>Khẩn cấp</span>
            </label>
        </div>

        <button class="btn btn-primary full" type="submit">Gửi yêu cầu</button>

        <?php if (!is_logged_in()): ?>
            <p class="form-note">
                <a href="<?= e(url('auth', 'login')) ?>">Đăng nhập</a> để theo dõi lịch sử hỗ trợ.
            </p>
        <?php endif; ?>
    </form>

    <aside class="summary-panel">
        <p class="eyebrow">Pizza House</p>
        <h2>Luôn sẵn sàng hỗ trợ</h2>

        <div class="support-contact-list">
            <div class="support-contact-item">
                <span>Hotline</span>
                <strong>0909 000 888</strong>
            </div>
            <div class="support-contact-item">
                <span>Thời gian phản hồi</span>
                <strong>Trong giờ mở cửa 09:00 - 22:00</strong>
            </div>
            <div class="support-contact-item">
                <span>Nội dung thường gặp</span>
                <strong>Đổi thông tin giao hàng, kiểm tra đơn, góp ý món ăn</strong>
            </div>
        </div>
    </aside>
</section>

<?php if (is_logged_in()): ?>
    <section class="container section support-history">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Theo dõi</p>
                <h2>Yêu cầu gần đây</h2>
            </div>
        </div>

        <?php if (empty($tickets)): ?>
            <div class="empty-state compact">
                <h3>Chưa có yêu cầu hỗ trợ</h3>
                <p>Các phản hồi từ Pizza House sẽ xuất hiện tại đây.</p>
            </div>
        <?php else: ?>
            <div class="table-wrap">
                <table class="data-table support-table">
                    <thead>
                    <tr>
                        <th>Mã</th>
                        <th>Chủ đề</th>
                        <th>Trạng thái</th>
                        <th>Mức độ</th>
                        <th>Phản hồi</th>
                        <th>Ngày gửi</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($tickets as $ticket): ?>
                        <tr>
                            <td><strong>#<?= e($ticket['id']) ?></strong></td>
                            <td>
                                <strong><?= e($ticket['subject']) ?></strong>
                                <span class="support-message"><?= nl2br(e($ticket['message'])) ?></span>
                            </td>
                            <td><span class="status ticket-status-<?= e($ticket['status']) ?>"><?= e(support_status_text($ticket['status'])) ?></span></td>
                            <td><span class="status ticket-priority-<?= e($ticket['priority']) ?>"><?= e(support_priority_text($ticket['priority'])) ?></span></td>
                            <td>
                                <?php if ($ticket['admin_reply']): ?>
                                    <div class="ticket-reply"><?= nl2br(e($ticket['admin_reply'])) ?></div>
                                <?php else: ?>
                                    <span style="color:var(--muted);">Đang chờ phản hồi</span>
                                <?php endif; ?>
                            </td>
                            <td><?= e(date('d/m/Y H:i', strtotime($ticket['created_at']))) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
<?php endif; ?>
