<?php
$isEdit = $product !== null;
?>

<section class="container section narrow">
    <div class="section-heading">
        <div>
            <p class="eyebrow">Admin</p>
            <h1><?= $isEdit ? 'Sửa sản phẩm' : 'Thêm sản phẩm' ?></h1>
        </div>
        <a class="btn btn-outline" href="<?= e(url('admin', 'products')) ?>">← Quay lại</a>
    </div>

    <form class="form-panel" method="post" action="<?= e(url('admin', 'saveProduct')) ?>">
        <?php if ($isEdit): ?>
            <input type="hidden" name="id" value="<?= e($product['id']) ?>">
        <?php endif; ?>

        <label>Tên sản phẩm</label>
        <input type="text" name="name" required value="<?= e($product['name'] ?? '') ?>">

        <label>Danh mục</label>
        <select name="category_id" required>
            <option value="">Chọn danh mục</option>
            <?php foreach ($categories as $category): ?>
                <option value="<?= e($category['id']) ?>" <?= (int)($product['category_id'] ?? 0) === (int)$category['id'] ? 'selected' : '' ?>>
                    <?= e($category['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>Mô tả</label>
        <textarea name="description" rows="4"><?= e($product['description'] ?? '') ?></textarea>

        <label>Giá (VNĐ)</label>
        <input type="number" name="price" min="1000" step="1000" required value="<?= e($product['price'] ?? '') ?>">

        <label>Đường dẫn ảnh trong thư mục img</label>
        <input type="text" name="image" value="<?= e($product['image'] ?? 'img/JTPSD2ONPYISBHIP4CJ5HDW55A_01.webp') ?>">

        <label class="check-row" style="margin-top:18px;">
            <input type="checkbox" name="status" value="1" <?= (int)($product['status'] ?? 1) === 1 ? 'checked' : '' ?>>
            <span>Đang bán</span>
        </label>

        <button class="btn btn-primary full" type="submit" style="margin-top:24px;"><?= $isEdit ? 'Lưu thay đổi' : 'Thêm sản phẩm' ?></button>
    </form>
</section>
