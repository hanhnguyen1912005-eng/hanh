<section class="container section">
    <div class="admin-head">
        <div>
            <p class="eyebrow">Admin</p>
            <h1>Bảng điều khiển</h1>
        </div>
        <div class="admin-actions">
            <a class="btn btn-outline" href="<?= e(url('admin', 'products')) ?>">Sản phẩm</a>
            <a class="btn btn-outline" href="<?= e(url('admin', 'orders')) ?>">Đơn hàng</a>
            <a class="btn btn-outline" href="<?= e(url('admin', 'coupons')) ?>"><?= icon('ticket', '', 14) ?> Mã giảm giá</a>
            <a class="btn btn-outline" href="<?= e(url('admin', 'reviews')) ?>">Đánh giá & Phản hồi</a>
            <a class="btn btn-outline" href="<?= e(url('admin', 'support')) ?>">CSKH</a>
            <a class="btn btn-outline" href="<?= e(url('admin', 'users')) ?>">Người dùng</a>
        </div>
    </div>

    <!-- STATS CARDS (BALANCED 4-COLUMN GRID) -->
    <div class="stats-grid">
        <div class="stat-card stat-card-featured">
            <div class="stat-card-header">
                <span>Tổng doanh thu tích lũy</span>
                <span class="stat-featured-badge"><?= icon('bar-chart', '', 13) ?> Doanh thu</span>
            </div>
            <strong class="stat-value-money"><?= money($stats['revenue']) ?></strong>
            <span class="stat-card-meta">Đơn hàng hoàn tất & đã trừ voucher</span>
        </div>
        <div class="stat-card">
            <span>Tổng đơn hàng</span>
            <strong><?= e($stats['orders']) ?> đơn</strong>
            <span class="stat-card-meta">Tất cả đơn đặt</span>
        </div>
        <div class="stat-card">
            <span>Sản phẩm đang bán</span>
            <strong><?= e($stats['products']) ?> món</strong>
            <span class="stat-card-meta">Thực đơn nhà hàng</span>
        </div>
        <div class="stat-card">
            <span>Mã giảm giá</span>
            <strong><?= e($stats['coupons']) ?> mã</strong>
            <span class="stat-card-meta text-success">(<?= $stats['coupons_active'] ?> đang hoạt động)</span>
        </div>
        <div class="stat-card">
            <span>Người dùng</span>
            <strong><?= e($stats['users']) ?></strong>
            <span class="stat-card-meta">Tài khoản thành viên</span>
        </div>
        <div class="stat-card">
            <span>Đánh giá khách</span>
            <strong><?= e($stats['reviews']) ?></strong>
            <?php if (!empty($stats['reviews_unreplied'])): ?>
                <span class="stat-card-meta text-danger">(<?= $stats['reviews_unreplied'] ?> chưa phản hồi)</span>
            <?php else: ?>
                <span class="stat-card-meta">100% đã phản hồi</span>
            <?php endif; ?>
        </div>
        <div class="stat-card">
            <span>Yêu cầu CSKH</span>
            <strong><?= e($stats['support']) ?></strong>
            <span class="stat-card-meta">Phiếu hỗ trợ khách</span>
        </div>
    </div>

    <!-- BIỂU ĐỒ 1: DOANH THU THEO NGÀY, TUẦN, THÁNG -->
    <div class="chart-panel" style="margin-top:32px;">
        <div class="chart-panel-header">
            <div>
                <p class="eyebrow"><?= icon('bar-chart', 'eyebrow-icon', 15) ?> Thống kê tài chính</p>
                <h2>Biểu đồ doanh thu bán hàng</h2>
            </div>
            <div class="chart-tabs-wrap">
                <button type="button" class="chart-tab-btn active" data-period="day">Theo ngày</button>
                <button type="button" class="chart-tab-btn" data-period="week">Theo tuần</button>
                <button type="button" class="chart-tab-btn" data-period="month">Theo tháng</button>
            </div>
        </div>
        <div class="chart-canvas-box" style="position:relative; height:320px; width:100%;">
            <canvas id="revenueTimeChart"></canvas>
        </div>
        <div class="chart-legend-footer">
            <span class="legend-indicator dot-revenue"></span> <span>Doanh thu thực tế (VND)</span>
            <span class="legend-sep">•</span>
            <span class="legend-indicator dot-orders"></span> <span>Số lượng đơn đặt</span>
        </div>
    </div>

    <!-- BIỂU ĐỒ 2: DOANH THU THEO DANH MỤC MÓN ĂN -->
    <div class="chart-panel" style="margin-top:32px;">
        <div class="chart-panel-header">
            <div>
                <p class="eyebrow"><?= icon('pie-chart', 'eyebrow-icon', 15) ?> Cơ cấu ẩm thực</p>
                <h2>Doanh thu theo danh mục (Pizza, Gà rán, Mì, Nước...)</h2>
            </div>
        </div>
        <div class="category-chart-grid">
            <div class="category-chart-canvas-box">
                <canvas id="categoryPieChart"></canvas>
            </div>
            <div class="category-chart-table-box">
                <table class="data-table compact-table">
                    <thead>
                    <tr>
                        <th>Danh mục</th>
                        <th>Đã bán</th>
                        <th>Doanh thu</th>
                        <th>Tỷ trọng</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($revenueByCategory)): ?>
                        <tr><td colspan="4" style="text-align:center;color:var(--muted);">Chưa có dữ liệu bán hàng.</td></tr>
                    <?php else: ?>
                        <?php foreach ($revenueByCategory as $catRev): ?>
                            <tr>
                                <td>
                                    <strong><?= e($catRev['category_name']) ?></strong>
                                </td>
                                <td><?= number_format($catRev['quantity']) ?> phần</td>
                                <td><strong style="color:var(--primary);"><?= money($catRev['revenue']) ?></strong></td>
                                <td>
                                    <div class="cat-percent-cell">
                                        <div class="cat-percent-track">
                                            <div class="cat-percent-fill" style="width:<?= $catRev['percent'] ?>%;"></div>
                                        </div>
                                        <span class="cat-percent-label"><?= $catRev['percent'] ?>%</span>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- ĐƠN HÀNG GẦN ĐÂY -->
    <div class="section-heading" style="margin-top:36px;">
        <div>
            <p class="eyebrow">Mới nhất</p>
            <h2>Đơn hàng gần đây</h2>
        </div>
        <a class="btn btn-outline btn-small" href="<?= e(url('admin', 'orders')) ?>">Xem tất cả đơn →</a>
    </div>

    <div class="table-wrap">
        <table class="data-table">
            <thead>
            <tr>
                <th>Mã</th>
                <th>Khách hàng</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
                <th>Thời gian</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($orders as $order): ?>
                <tr>
                    <td><strong>#<?= e($order['id']) ?></strong></td>
                    <td>
                        <strong><?= e($order['customer_name']) ?></strong><br>
                        <span style="color:var(--muted);font-size:12.5px;"><?= e($order['customer_phone']) ?></span>
                    </td>
                    <td>
                        <strong><?= money($order['total_amount']) ?></strong>
                        <?php if (!empty($order['coupon_code'])): ?>
                            <br><span class="coupon-tag-mini"><?= icon('ticket', '', 12) ?> <?= e($order['coupon_code']) ?> (-<?= money($order['discount_amount']) ?>)</span>
                        <?php endif; ?>
                    </td>
                    <td><span class="status"><?= e(order_status_text($order['status'])) ?></span></td>
                    <td style="color:var(--muted);font-size:13px;"><?= date('d/m/Y H:i', strtotime($order['created_at'])) ?></td>
                    <td><a class="btn btn-small btn-outline" href="<?= e(url('order', 'detail', ['id' => $order['id']])) ?>">Xem</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<!-- CHART.JS INTEGRATION -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const timeData = {
        day: <?= json_encode($revenueByDay) ?>,
        week: <?= json_encode($revenueByWeek) ?>,
        month: <?= json_encode($revenueByMonth) ?>
    };

    const catData = <?= json_encode($revenueByCategory) ?>;

    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    const gridColor = isDark ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.06)';
    const textColor = isDark ? '#a8988b' : '#64748b';

    // 1. INITIALIZE REVENUE TIME CHART
    const timeCanvas = document.getElementById('revenueTimeChart');
    let currentPeriod = 'day';
    let revenueChart = null;

    function buildTimeChart(period) {
        const raw = timeData[period] || [];
        const labels = raw.map(item => item.label);
        const revenues = raw.map(item => item.revenue);
        const orders = raw.map(item => item.order_count);

        if (revenueChart) {
            revenueChart.destroy();
        }

        const ctx = timeCanvas.getContext('2d');
        const gradient = ctx.createLinearGradient(0, 0, 0, 300);
        gradient.addColorStop(0, 'rgba(229, 75, 45, 0.35)');
        gradient.addColorStop(1, 'rgba(229, 75, 45, 0.0)');

        revenueChart = new Chart(timeCanvas, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Doanh thu (VND)',
                        data: revenues,
                        borderColor: '#e54b2d',
                        backgroundColor: gradient,
                        borderWidth: 3,
                        pointBackgroundColor: '#ffffff',
                        pointBorderColor: '#e54b2d',
                        pointBorderWidth: 2,
                        pointRadius: 4,
                        pointHoverRadius: 7,
                        tension: 0.38,
                        fill: true,
                        yAxisID: 'y'
                    },
                    {
                        label: 'Số đơn hàng',
                        data: orders,
                        type: 'bar',
                        backgroundColor: isDark ? 'rgba(245, 158, 11, 0.45)' : 'rgba(245, 158, 11, 0.65)',
                        hoverBackgroundColor: '#f59e0b',
                        borderRadius: 6,
                        barPercentage: 0.35,
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: isDark ? '#271c13' : '#1c140d',
                        titleColor: '#fdfaf6',
                        bodyColor: '#ffffff',
                        borderColor: isDark ? '#4d3624' : '#e54b2d',
                        borderWidth: 1,
                        padding: 12,
                        boxPadding: 6,
                        usePointStyle: true,
                        callbacks: {
                            label: function (context) {
                                if (context.dataset.yAxisID === 'y') {
                                    return 'Doanh thu: ' + new Intl.NumberFormat('vi-VN').format(context.raw) + ' đ';
                                } else {
                                    return 'Số đơn đặt: ' + context.raw + ' đơn';
                                }
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: gridColor,
                            drawBorder: false
                        },
                        ticks: {
                            color: textColor,
                            font: {
                                family: 'Nunito',
                                size: 12,
                                weight: '600'
                            }
                        }
                    },
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        grid: {
                            color: gridColor,
                            drawBorder: false
                        },
                        ticks: {
                            color: textColor,
                            font: {
                                family: 'Nunito',
                                size: 11
                            },
                            callback: function (val) {
                                if (val >= 1000000) return (val / 1000000) + 'Tr';
                                if (val >= 1000) return (val / 1000) + 'K';
                                return val;
                            }
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        grid: {
                            drawOnChartArea: false,
                            drawBorder: false
                        },
                        ticks: {
                            color: '#f59e0b',
                            precision: 0,
                            font: {
                                family: 'Nunito',
                                size: 11
                            }
                        }
                    }
                }
            }
        });
    }

    if (timeCanvas) {
        buildTimeChart(currentPeriod);
    }

    // TABS SWITCHER
    const tabBtns = document.querySelectorAll('.chart-tab-btn');
    tabBtns.forEach(btn => {
        btn.addEventListener('click', function () {
            tabBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            const period = this.getAttribute('data-period');
            if (period !== currentPeriod) {
                currentPeriod = period;
                buildTimeChart(currentPeriod);
            }
        });
    });

    // 2. INITIALIZE CATEGORY DOUGHNUT CHART
    const catCanvas = document.getElementById('categoryPieChart');
    if (catCanvas && catData.length > 0) {
        const catLabels = catData.map(item => item.category_name);
        const catRevenues = catData.map(item => item.revenue);

        const palette = [
            '#e54b2d', // Pizza truyền thống
            '#0284c7', // Pizza hải sản
            '#f59e0b', // Pizza đặc biệt
            '#d97706', // Gà rán giòn rụm
            '#10b981', // Mì Ý & Khai vị
            '#ef4444', // Mì nước
            '#06b6d4', // Đồ uống
            '#8b5cf6'  // Combo Khuyến mãi
        ];

        new Chart(catCanvas, {
            type: 'doughnut',
            data: {
                labels: catLabels,
                datasets: [{
                    data: catRevenues,
                    backgroundColor: palette.slice(0, catLabels.length),
                    borderColor: isDark ? '#1c140d' : '#ffffff',
                    borderWidth: 3,
                    hoverOffset: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '62%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: textColor,
                            font: {
                                family: 'Nunito',
                                size: 12,
                                weight: '600'
                            },
                            padding: 12,
                            boxWidth: 12,
                            boxHeight: 12,
                            usePointStyle: true
                        }
                    },
                    tooltip: {
                        backgroundColor: isDark ? '#271c13' : '#1c140d',
                        titleColor: '#fdfaf6',
                        bodyColor: '#ffffff',
                        borderColor: isDark ? '#4d3624' : '#e54b2d',
                        borderWidth: 1,
                        padding: 12,
                        callbacks: {
                            label: function (context) {
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const val = context.raw;
                                const pct = total > 0 ? ((val / total) * 100).toFixed(1) : 0;
                                return ' Doanh thu: ' + new Intl.NumberFormat('vi-VN').format(val) + ' đ (' + pct + '%)';
                            }
                        }
                    }
                }
            }
        });
    }
});
</script>
