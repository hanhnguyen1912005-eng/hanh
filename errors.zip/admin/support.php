<section class="container section">
    <div class="admin-head">
        <div>
            <p class="eyebrow">Admin</p>
            <h1>Quản lý CSKH</h1>
        </div>
        <a class="btn btn-outline" href="<?= e(url('admin', 'dashboard')) ?>">← Dashboard</a>
    </div>

    <?php if (empty($tickets)): ?>
        <div class="empty-state compact">
            <h3>Chưa có yêu cầu hỗ trợ</h3>
            <p>Khi khách hàng gửi yêu cầu, danh sách sẽ hiển thị tại đây.</p>
        </div>
    <?php else: ?>
        <div class="table-wrap">
            <table class="data-table support-admin-table">
                <thead>
                <tr>
                    <th>Mã</th>
                    <th>Khách hàng</th>
                    <th>Nội dung</th>
                    <th>Đơn hàng</th>
                    <th>Xử lý</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($tickets as $ticket): ?>
                    <tr>
                        <td>
                            <strong>#<?= e($ticket['id']) ?></strong><br>
                            <span style="color:var(--muted);font-size:13px;"><?= e(date('d/m/Y H:i', strtotime($ticket['created_at']))) ?></span>
                        </td>
                        <td>
                            <strong><?= e($ticket['customer_name']) ?></strong><br>
                            <span style="color:var(--muted);font-size:13px;"><?= e($ticket['customer_phone']) ?></span><br>
                            <span style="color:var(--muted);font-size:13px;"><?= e($ticket['customer_email']) ?></span>
                        </td>
                        <td>
                            <strong><?= e($ticket['subject']) ?></strong>
                            <span class="support-message"><?= nl2br(e($ticket['message'])) ?></span>
                            <div class="support-meta-row">
                                <span class="status ticket-status-<?= e($ticket['status']) ?>"><?= e(support_status_text($ticket['status'])) ?></span>
                                <span class="status ticket-priority-<?= e($ticket['priority']) ?>"><?= e(support_priority_text($ticket['priority'])) ?></span>
                            </div>
                        </td>
                        <td>
                            <?php if ($ticket['order_id']): ?>
                                <a class="btn btn-small btn-outline" href="<?= e(url('order', 'detail', ['id' => $ticket['order_id']])) ?>">
                                    #<?= e($ticket['order_id']) ?>
                                </a>
                            <?php else: ?>
                                <span style="color:var(--muted);">Không có</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <form class="support-response-card" method="post" action="<?= e(url('admin', 'updateSupportTicket')) ?>">
                                <input type="hidden" name="id" value="<?= e($ticket['id']) ?>">
                                
                                <div class="support-card-controls">
                                    <div class="support-field-group">
                                        <label class="support-field-label">Trạng thái</label>
                                        <div class="support-select-wrapper">
                                            <select name="status" class="support-select-styled">
                                                <?php foreach (['new', 'in_progress', 'resolved', 'closed'] as $status): ?>
                                                    <option value="<?= e($status) ?>" <?= $ticket['status'] === $status ? 'selected' : '' ?>>
                                                        <?= e(support_status_text($status)) ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="support-field-group">
                                        <label class="support-field-label">Ưu tiên</label>
                                        <div class="support-select-wrapper">
                                            <select name="priority" class="support-select-styled">
                                                <?php foreach (['normal', 'urgent'] as $priority): ?>
                                                    <option value="<?= e($priority) ?>" <?= $ticket['priority'] === $priority ? 'selected' : '' ?>>
                                                        <?= e(support_priority_text($priority)) ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="support-textarea-wrap">
                                    <div class="support-textarea-head">
                                        <label class="support-field-label">Phản hồi của CSKH</label>
                                        <?php if (!empty($ticket['admin_reply'])): ?>
                                            <span class="support-reply-badge"><?= icon('check', '', 12) ?> Đã có phản hồi</span>
                                        <?php endif; ?>
                                    </div>
                                    <textarea name="admin_reply" class="support-textarea-styled" rows="3" placeholder="Nhập nội dung phản hồi gửi khách hàng..."><?= e($ticket['admin_reply']) ?></textarea>
                                </div>

                                <div class="support-card-actions">
                                    <button class="btn btn-small btn-primary support-btn-save" type="submit">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg>
                                        Lưu phản hồi
                                    </button>
                                </div>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
