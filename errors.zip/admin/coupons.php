<section class="container section">
    <div class="admin-head">
        <div>
            <p class="eyebrow">Admin</p>
            <h1>Quản lý mã giảm giá (Coupons)</h1>
        </div>
        <div class="admin-actions">
            <a class="btn btn-outline" href="<?= e(url('admin', 'dashboard')) ?>">← Dashboard</a>
            <a class="btn btn-primary" href="#create-coupon">+ Thêm mã mới</a>
        </div>
    </div>

    <!-- DANH SÁCH MÃ GIẢM GIÁ -->
    <div class="table-wrap" style="margin-bottom:36px;">
        <table class="data-table">
            <thead>
            <tr>
                <th>Mã code</th>
                <th>Mô tả</th>
                <th>Mức giảm</th>
                <th>Đơn tối thiểu</th>
                <th>Lượt sử dụng</th>
                <th>Hạn dùng</th>
                <th>Trạng thái</th>
                <th>Thao tác</th>
            </tr>
            </thead>
            <tbody>
            <?php if (empty($coupons)): ?>
                <tr>
                    <td colspan="8" style="text-align:center;padding:32px;color:var(--muted);">Chưa có mã giảm giá nào. Hãy tạo mã đầu tiên bên dưới!</td>
                </tr>
            <?php else: ?>
                <?php foreach ($coupons as $c): ?>
                    <tr>
                        <td>
                            <strong class="coupon-badge"><?= icon('ticket', '', 14) ?> <?= e($c['code']) ?></strong>
                        </td>
                        <td><?= e($c['description'] ?: 'Không có mô tả') ?></td>
                        <td>
                            <strong style="color:var(--primary);">
                                <?= $c['discount_type'] === 'percent' ? (int)$c['discount_value'] . '% (Tối đa ' . money($c['max_discount_amount'] ?: 0) . ')' : money($c['discount_value']) ?>
                            </strong>
                        </td>
                        <td><?= (float)$c['min_order_amount'] > 0 ? money($c['min_order_amount']) : 'Không giới hạn' ?></td>
                        <td>
                            <strong><?= (int)$c['used_count'] ?></strong>
                            <?= !empty($c['usage_limit']) ? ' / ' . (int)$c['usage_limit'] : ' (Không giới hạn)' ?>
                        </td>
                        <td>
                            <?php if (!empty($c['expires_at'])): ?>
                                <?= date('d/m/Y', strtotime($c['expires_at'])) ?>
                            <?php else: ?>
                                <span style="color:var(--muted);">Vô thời hạn</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ((int)$c['status'] === 1): ?>
                                <span class="status status-active" style="background:#e6f4ea;color:#137333;font-weight:700;padding:4px 10px;border-radius:12px;">Đang chạy</span>
                            <?php else: ?>
                                <span class="status status-paused" style="background:#f1f3f4;color:#5f6368;font-weight:700;padding:4px 10px;border-radius:12px;">Tạm ngưng</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div style="display:flex;gap:8px;align-items:center;">
                                <a class="btn btn-small <?= (int)$c['status'] === 1 ? 'btn-outline' : 'btn-dark' ?>" 
                                   href="<?= e(url('admin', 'toggleCoupon', ['id' => $c['id']])) ?>">
                                    <?= (int)$c['status'] === 1 ? 'Tạm ngưng' : 'Kích hoạt' ?>
                                </a>
                                <a class="btn btn-small btn-ghost text-danger" 
                                   href="<?= e(url('admin', 'deleteCoupon', ['id' => $c['id']])) ?>" 
                                   onclick="return confirm('Bạn có chắc muốn xóa mã <?= e($c['code']) ?> không?');" 
                                   title="Xóa mã này">
                                    <?= icon('trash', '', 14) ?>
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- FORM THÊM MÃ GIẢM GIÁ MỚI -->
    <div id="create-coupon" class="form-panel" style="max-width:760px;margin:0 auto;">
        <div class="section-heading" style="margin-bottom:18px;">
            <div>
                <p class="eyebrow"><?= icon('ticket', '', 15) ?> Tạo khuyến mãi</p>
                <h2>Thêm mã giảm giá mới</h2>
            </div>
        </div>

        <form method="post" action="<?= e(url('admin', 'saveCoupon')) ?>">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                <div>
                    <label>Mã code <span class="text-danger">*</span></label>
                    <input type="text" name="code" placeholder="Ví dụ: PIZZA30K, SALE20..." required style="text-transform:uppercase;font-weight:700;letter-spacing:.05em;">
                </div>
                <div>
                    <label>Hình thức giảm <span class="text-danger">*</span></label>
                    <select name="discount_type" id="discountTypeSelect" onchange="toggleDiscountFields()">
                        <option value="fixed">Giảm số tiền cố định (VND)</option>
                        <option value="percent">Giảm theo phần trăm (%)</option>
                    </select>
                </div>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:12px;">
                <div>
                    <label id="discountValueLabel">Số tiền giảm (VND) <span class="text-danger">*</span></label>
                    <input type="number" name="discount_value" placeholder="Ví dụ: 20000" min="1" step="1000" required>
                </div>
                <div id="maxDiscountWrap" style="display:none;">
                    <label>Mức giảm tối đa (VND)</label>
                    <input type="number" name="max_discount_amount" placeholder="Ví dụ: 50000" min="0" step="1000">
                </div>
                <div>
                    <label>Đơn tối thiểu áp dụng (VND)</label>
                    <input type="number" name="min_order_amount" placeholder="Ví dụ: 100000" min="0" step="1000" value="0">
                </div>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:12px;">
                <div>
                    <label>Giới hạn số lượt dùng (để trống = vô hạn)</label>
                    <input type="number" name="usage_limit" placeholder="Ví dụ: 100" min="1">
                </div>
                <div>
                    <label>Ngày hết hạn (để trống = không hết hạn)</label>
                    <input type="date" name="expires_at">
                </div>
            </div>

            <div style="margin-top:12px;">
                <label>Mô tả chi tiết</label>
                <textarea name="description" rows="2" placeholder="Ví dụ: Giảm 30.000đ cho đơn hàng từ 150.000đ"></textarea>
            </div>

            <button type="submit" class="btn btn-primary" style="margin-top:18px;">
                <?= icon('check', '', 16) ?> Lưu & Kích hoạt mã giảm giá
            </button>
        </form>
    </div>
</section>

<script>
function toggleDiscountFields() {
    const sel = document.getElementById('discountTypeSelect');
    const lbl = document.getElementById('discountValueLabel');
    const maxWrap = document.getElementById('maxDiscountWrap');
    if (sel && sel.value === 'percent') {
        lbl.innerHTML = 'Phần trăm giảm (%) <span class="text-danger">*</span>';
        if (maxWrap) maxWrap.style.display = 'block';
    } else {
        lbl.innerHTML = 'Số tiền giảm (VND) <span class="text-danger">*</span>';
        if (maxWrap) maxWrap.style.display = 'none';
    }
}
</script>
