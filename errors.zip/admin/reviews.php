<div class="container section">
    <div class="section-heading">
        <div>
            <p class="eyebrow">Quản trị cửa hàng</p>
            <h2>Quản lý đánh giá & Phản hồi khách hàng</h2>
        </div>
        <a class="btn btn-outline btn-small" href="<?= e(url('admin', 'dashboard')) ?>">&larr; Quay lại Dashboard</a>
    </div>

    <!-- FILTER TABS -->
    <div class="admin-review-filters">
        <a href="<?= e(url('admin', 'reviews')) ?>" class="review-filter-btn <?= $filter === '' ? 'active' : '' ?>">
            Tất cả đánh giá (<?= $totalCount ?>)
        </a>
        <a href="<?= e(url('admin', 'reviews', ['filter' => 'unreplied'])) ?>" class="review-filter-btn <?= $filter === 'unreplied' ? 'active' : '' ?>">
            <?= icon('alert', '', 14) ?> Chưa phản hồi (<?= $unrepliedCount ?>)
        </a>
        <a href="<?= e(url('admin', 'reviews', ['filter' => 'replied'])) ?>" class="review-filter-btn <?= $filter === 'replied' ? 'active' : '' ?>">
            <?= icon('check', '', 14) ?> Đã phản hồi (<?= $totalCount - $unrepliedCount ?>)
        </a>
    </div>

    <?php if (empty($reviews)): ?>
        <div class="empty-state">
            <h3>Không có đánh giá nào phù hợp</h3>
            <p>Hiện chưa có đánh giá nào trong bộ lọc này.</p>
        </div>
    <?php else: ?>
        <div class="admin-reviews-container">
            <?php foreach ($reviews as $item): ?>
                <div class="admin-review-card <?= empty($item['admin_reply']) ? 'is-unreplied' : '' ?>">
                    <div class="admin-review-product-row">
                        <div class="admin-review-product-info">
                            <img src="<?= e($item['product_image'] ?: 'img/JTPSD2ONPYISBHIP4CJ5HDW55A_01.webp') ?>" alt="<?= e($item['product_name']) ?>" class="admin-prod-thumb">
                            <div>
                                <a href="<?= e(url('product', 'detail', ['id' => $item['product_id']])) ?>" target="_blank" class="admin-prod-link">
                                    <strong><?= e($item['product_name']) ?></strong> ↗
                                </a>
                                <div class="admin-review-author-line">
                                    <span><?= icon('user', '', 14) ?> <?= e($item['customer_name']) ?></span>
                                    <?php if (!empty($item['customer_email'])): ?>
                                        <span class="muted-text">(<?= e($item['customer_email']) ?>)</span>
                                    <?php endif; ?>
                                    <span class="dot-separator">•</span>
                                    <span><?= icon('clock', '', 14) ?> <?= date('d/m/Y H:i', strtotime($item['created_at'])) ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="admin-review-rating-box">
                            <span class="admin-stars">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <span class="star <?= $i <= (int) $item['rating'] ? 'active' : '' ?>"><?= icon('star', '', 14) ?></span>
                                <?php endfor; ?>
                            </span>
                            <span class="admin-rating-number"><?= (int) $item['rating'] ?>/5</span>
                        </div>
                    </div>

                    <div class="admin-review-comment-box">
                        <p><strong>Nhận xét:</strong> "<?= e($item['comment']) ?>"</p>
                    </div>

                    <!-- FORM PHẢN HỒI ĐÁNH GIÁ -->
                    <div class="admin-reply-box-wrap">
                        <form method="post" action="<?= e(url('admin', 'replyReview')) ?>" class="admin-reply-form">
                            <input type="hidden" name="id" value="<?= e($item['id']) ?>">
                            <input type="hidden" name="filter" value="<?= e($filter) ?>">
                            
                            <label class="admin-reply-label">
                                <?= icon('message', '', 16) ?> <strong>Phản hồi từ Pizza House:</strong>
                                <?php if (!empty($item['admin_reply'])): ?>
                                    <span class="admin-reply-status-replied">(Đã trả lời lúc <?= date('d/m/Y H:i', strtotime($item['admin_replied_at'])) ?>)</span>
                                <?php else: ?>
                                    <span class="admin-reply-status-pending">(Chưa trả lời)</span>
                                <?php endif; ?>
                            </label>

                            <textarea name="admin_reply" rows="2" class="form-control admin-reply-textarea" 
                                      placeholder="Viết câu trả lời cảm ơn hoặc giải đáp thắc mắc của khách..."><?= e($item['admin_reply'] ?? '') ?></textarea>

                            <div class="admin-reply-actions-row">
                                <button type="submit" class="btn btn-primary btn-small">
                                    <?= !empty($item['admin_reply']) ? 'Cập nhật phản hồi' : 'Gửi phản hồi khách hàng' ?>
                                </button>
                                
                                <a href="<?= e(url('admin', 'deleteReview', ['id' => $item['id'], 'filter' => $filter])) ?>" 
                                   class="btn btn-outline btn-small btn-danger-text" 
                                   onclick="return confirm('Bạn có chắc chắn muốn xóa đánh giá này không?');">
                                    <?= icon('trash', '', 14) ?> Xóa đánh giá
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
