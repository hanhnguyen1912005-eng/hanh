<section class="container section">
    <div class="admin-head">
        <div>
            <p class="eyebrow">Admin</p>
            <h1>Quản lý người dùng</h1>
        </div>
        <a class="btn btn-outline" href="<?= e(url('admin', 'dashboard')) ?>">← Dashboard</a>
    </div>

    <div class="table-wrap">
        <table class="data-table">
            <thead>
            <tr>
                <th>ID</th>
                <th>Họ tên</th>
                <th>Email</th>
                <th>Số điện thoại</th>
                <th>Vai trò</th>
                <th>Ngày tạo</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><strong>#<?= e($user['id']) ?></strong></td>
                    <td><?= e($user['name']) ?></td>
                    <td><?= e($user['email']) ?></td>
                    <td><?= e($user['phone']) ?></td>
                    <td>
                        <?php if ($user['role'] === 'admin'): ?>
                            <span class="status" style="background:var(--amber-bg);color:var(--amber);">Admin</span>
                        <?php else: ?>
                            <span class="status">Khách</span>
                        <?php endif; ?>
                    </td>
                    <td><?= e(date('d/m/Y', strtotime($user['created_at']))) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
