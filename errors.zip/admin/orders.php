<section class="container section">
    <div class="admin-head">
        <div>
            <p class="eyebrow">Admin</p>
            <h1>Quản lý đơn hàng</h1>
        </div>
        <a class="btn btn-outline" href="<?= e(url('admin', 'dashboard')) ?>">← Dashboard</a>
    </div>

    <div class="table-wrap">
        <table class="data-table">
            <thead>
            <tr>
                <th>Mã</th>
                <th>Khách hàng</th>
                <th>Tổng tiền</th>
                <th>Trạng thái & Thanh toán</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($orders as $order): ?>
                <tr>
                    <td><strong>#<?= e($order['id']) ?></strong></td>
                    <td>
                        <strong><?= e($order['customer_name']) ?></strong><br>
                        <span style="color:var(--muted);font-size:13px;"><?= e($order['customer_phone']) ?></span>
                    </td>
                    <td>
                        <strong><?= money($order['total_amount']) ?></strong>
                        <?php if (!empty($order['coupon_code'])): ?>
                            <br><span class="coupon-tag-mini"><?= icon('ticket', '', 12) ?> <?= e($order['coupon_code']) ?> (-<?= money($order['discount_amount']) ?>)</span>
                        <?php endif; ?>
                    </td>
                    <td colspan="1">
                        <form class="inline-form" method="post" action="<?= e(url('admin', 'updateOrder')) ?>">
                            <input type="hidden" name="id" value="<?= e($order['id']) ?>">
                            <select name="status">
                                <?php foreach (['pending', 'confirmed', 'shipping', 'completed', 'cancelled'] as $status): ?>
                                    <option value="<?= e($status) ?>" <?= $order['status'] === $status ? 'selected' : '' ?>>
                                        <?= e(order_status_text($status)) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <select name="payment_status">
                                <?php foreach (['pending', 'paid', 'unpaid', 'failed'] as $status): ?>
                                    <option value="<?= e($status) ?>" <?= $order['payment_status'] === $status ? 'selected' : '' ?>>
                                        <?= e(payment_status_text($status)) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <button class="btn btn-small btn-dark" type="submit">Lưu</button>
                        </form>
                    </td>
                    <td><a class="btn btn-small btn-outline" href="<?= e(url('order', 'detail', ['id' => $order['id']])) ?>">Xem</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
