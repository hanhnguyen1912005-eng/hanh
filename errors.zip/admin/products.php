<section class="container section">
    <div class="admin-head">
        <div>
            <p class="eyebrow">Admin</p>
            <h1>Quản lý sản phẩm</h1>
        </div>
        <a class="btn btn-primary" href="<?= e(url('admin', 'createProduct')) ?>">+ Thêm sản phẩm</a>
    </div>

    <div class="table-wrap">
        <table class="data-table">
            <thead>
            <tr>
                <th>Sản phẩm</th>
                <th>Danh mục</th>
                <th>Giá</th>
                <th>Trạng thái</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($products as $product): ?>
                <tr>
                    <td class="product-cell">
                        <img src="<?= e($product['image'] ?: 'img/JTPSD2ONPYISBHIP4CJ5HDW55A_01.webp') ?>" alt="<?= e($product['name']) ?>">
                        <div>
                            <strong><?= e($product['name']) ?></strong>
                            <span><?= e($product['description']) ?></span>
                        </div>
                    </td>
                    <td><?= e($product['category_name']) ?></td>
                    <td><?= money($product['price']) ?></td>
                    <td>
                        <?php if ((int)$product['status'] === 1): ?>
                            <span class="status">Đang bán</span>
                        <?php else: ?>
                            <span class="status" style="background:#f3f4f6;color:#6b7280;">Đã ẩn</span>
                        <?php endif; ?>
                    </td>
                    <td class="actions-cell">
                        <a class="btn btn-small btn-outline" href="<?= e(url('admin', 'editProduct', ['id' => $product['id']])) ?>">Sửa</a>
                        <a class="btn btn-small btn-danger" href="<?= e(url('admin', 'deleteProduct', ['id' => $product['id']])) ?>" onclick="return confirm('Ẩn sản phẩm này?')">Ẩn</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
