<section class="hero" style="background-image: linear-gradient(90deg, rgba(23,15,10,.94) 0%, rgba(23,15,10,.75) 55%, rgba(23,15,10,.4) 100%), url('img/istockphoto-1442417585-612x612.jpg');">
    <div class="container hero-inner">
        <div class="hero-content">
            <div class="hero-badge-pill">
                <?= icon('pizza', 'eyebrow-icon', 18) ?>
                <span>Nướng lò đá truyền thống • Bột ủ men tự nhiên 24h</span>
            </div>
            <h1>Thưởng thức vị ngon<br><span class="hero-highlight">Đậm đà phong vị Ý</span></h1>
            <p>Trải nghiệm pizza viền phồng giòn rụm, gà rán vàng ươm tắm sốt cay và mì Ý phô mai kéo sợi hảo hạng – giao nóng tận nơi trong 30 phút.</p>
            <div class="hero-actions">
                <a class="btn btn-primary btn-hero-cta" href="#menu">
                    <span>Xem thực đơn ngay</span>
                    <?= icon('arrow-right', '', 18) ?>
                </a>
                <a class="btn btn-light" href="<?= e(url('promotion', 'index')) ?>">
                    <?= icon('flame', 'text-primary', 18) ?>
                    <span>Khuyến mãi hấp dẫn</span>
                </a>
            </div>
            <div class="hero-stats-row">
                <div class="hero-stat-item">
                    <strong>30+</strong>
                    <span>Món ngon đặc sắc</span>
                </div>
                <div class="hero-stat-sep"></div>
                <div class="hero-stat-item">
                    <strong>4.9 <?= icon('star', 'text-amber', 18) ?></strong>
                    <span>Đánh giá hài lòng</span>
                </div>
                <div class="hero-stat-sep"></div>
                <div class="hero-stat-item">
                    <strong>30 Phút</strong>
                    <span>Cam kết giao nóng</span>
                </div>
            </div>
        </div>

        <!-- HERO VIDEO SHOWCASE -->
        <div class="hero-video-card">
            <div class="hero-video-glow"></div>
            <div class="hero-video-wrapper">
                <video id="heroVideo" class="hero-video-player" autoplay muted loop playsinline poster="img/istockphoto-1442417585-612x612.jpg" preload="metadata">
                    <source src="videos/Pizza%20Hut%20Sourdough%20Pizza%20-%20Perfectly%20Imperfect.mp4" type="video/mp4">
                    Trình duyệt của bạn không hỗ trợ thẻ video.
                </video>
                <div class="hero-video-overlay-badge">
                    <?= icon('film', '', 14) ?>
                    <span>Nghệ thuật bánh men tự nhiên</span>
                </div>
                <div class="hero-video-controls">
                    <button type="button" class="hero-video-btn" id="heroVideoToggleBtn" aria-label="Tạm dừng hoặc phát video" title="Tạm dừng / Phát">
                        <span class="icon-pause" id="heroVideoPauseIcon"><?= icon('pause', '', 15) ?></span>
                        <span class="icon-play" id="heroVideoPlayIcon" style="display:none;"><?= icon('play', '', 15) ?></span>
                    </button>
                    <button type="button" class="hero-video-btn" id="heroVideoMuteBtn" aria-label="Bật hoặc tắt âm thanh" title="Bật / Tắt âm thanh">
                        <span class="icon-muted" id="heroVideoMutedIcon"><?= icon('volume-x', '', 15) ?></span>
                        <span class="icon-unmuted" id="heroVideoUnmutedIcon" style="display:none;"><?= icon('volume-2', '', 15) ?></span>
                    </button>
                </div>
            </div>
            <div class="hero-video-footer-info">
                <span class="hero-video-live-dot"></span>
                <span>Nướng lò đá nhiệt độ cao 350°C viền phồng giòn tan</span>
            </div>
        </div>
    </div>
</section>

<!-- USP FEATURE BENEFITS STRIP -->
<section class="usp-feature-strip">
    <div class="container usp-grid">
        <div class="usp-card">
            <div class="usp-icon-box"><?= icon('truck', '', 24) ?></div>
            <div>
                <strong>Giao nhanh 30 phút</strong>
                <p>Pizza luôn nóng giòn khi tới tay</p>
            </div>
        </div>
        <div class="usp-card">
            <div class="usp-icon-box"><?= icon('sparkle', '', 24) ?></div>
            <div>
                <strong>100% Nguyên liệu sạch</strong>
                <p>Phô mai Mozzarella New Zealand</p>
            </div>
        </div>
        <div class="usp-card">
            <div class="usp-icon-box"><?= icon('shield', '', 24) ?></div>
            <div>
                <strong>Bảo đảm chất lượng</strong>
                <p>Đổi món miễn phí nếu không hài lòng</p>
            </div>
        </div>
        <div class="usp-card">
            <div class="usp-icon-box"><?= icon('gift', '', 24) ?></div>
            <div>
                <strong>Ưu đãi mỗi ngày</strong>
                <p>Mua 1 tặng 1 & combo siêu tiết kiệm</p>
            </div>
        </div>
    </div>
</section>

<!-- BANNER KHUYẾN MÃI CUỘN NGANG (GIAO DIỆN GIỐNG ẢNH: 3D PEEKING + NÚT TRÒN CAM <> HAI BÊN) -->
<section class="promo-banner-section">
    <div class="container promo-header-row">
        <div>
            <p class="eyebrow"><?= icon('flame', 'eyebrow-icon', 18) ?> Ưu đãi độc quyền</p>
            <h2>Khuyến mãi hấp dẫn</h2>
        </div>
        <a class="btn btn-small btn-outline" href="<?= e(url('promotion', 'index')) ?>">Tất cả khuyến mãi →</a>
    </div>

    <!-- CAROUSEL WRAPPER WITH FLOATING ORANGE CHEVRONS (< >) -->
    <div class="promo-carousel-wrapper">
        <!-- Nút tròn màu cam điều hướng bên trái (<) -->
        <button class="promo-arrow-btn promo-prev" id="promoPrevBtn" aria-label="Khuyến mãi trước" type="button">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="15 18 9 12 15 6"></polyline>
            </svg>
        </button>

        <div class="promo-slider-track" id="promoTrack">
            <!-- Banner 5: Deal choáy & iu đầy 89k (Peeking on left) -->
            <div class="promo-slide" data-index="0">
                <a href="<?= e(url('promotion', 'index')) ?>" class="promo-banner-link">
                    <img src="img/khuyenmai5.jpg" alt="Combo Một Tình Iu Một Cái Deal 89.000đ" loading="lazy">
                    <div class="promo-tag"><?= icon('tag', '', 14) ?> Deal Choáy 89K</div>
                </a>
            </div>

            <!-- Banner 3: Hẹn hò tiệc gà 99k (Active Center - Giống ảnh mẫu) -->
            <div class="promo-slide is-active" data-index="1">
                <a href="<?= e(url('promotion', 'index')) ?>" class="promo-banner-link">
                    <img src="img/khuyenmai3.jpg" alt="Tiệc Gà Hẹn Hò 4 Miếng Gà + 2 Nước Chỉ 99.000đ" loading="lazy">
                    <div class="promo-tag"><?= icon('flame', '', 14) ?> Tiệc Gà 99K - Giảm 47%</div>
                </a>
            </div>

            <!-- Banner 4: Chấm xốt lắm chiêu (Peeking on right - Giống ảnh mẫu) -->
            <div class="promo-slide" data-index="2">
                <a href="<?= e(url('promotion', 'index')) ?>" class="promo-banner-link">
                    <img src="img/khuyenmai4.jpg" alt="Phiêu Tiệc Đẫm Chấm Xốt Lắm Chiêu" loading="lazy">
                    <div class="promo-tag"><?= icon('soup', '', 14) ?> Tiệc Đẫm Chấm Xốt Từ 99K</div>
                </a>
            </div>

            <!-- Banner 2: Pizza Hoàng Kim Lava Combo -->
            <div class="promo-slide" data-index="3">
                <a href="<?= e(url('promotion', 'index')) ?>" class="promo-banner-link">
                    <img src="img/khuyenmai2.webp" alt="Pizza Hoàng Kim LAVA Combo - Tiết kiệm đến 30%" loading="lazy">
                    <div class="promo-tag"><?= icon('zap', '', 14) ?> Lava Combo - Giảm 30%</div>
                </a>
            </div>

            <!-- Banner 1: Mua 1 tặng 1 pizza -->
            <div class="promo-slide" data-index="4">
                <a href="<?= e(url('promotion', 'index')) ?>" class="promo-banner-link">
                    <img src="img/khuyenmai1.webp" alt="Ưu đãi Mua 1 Tặng 1 Pizza House" loading="lazy">
                    <div class="promo-tag"><?= icon('gift', '', 14) ?> Mua 1 Tặng 1 Pizza</div>
                </a>
            </div>
        </div>

        <!-- Nút tròn màu cam điều hướng bên phải (>) -->
        <button class="promo-arrow-btn promo-next" id="promoNextBtn" aria-label="Khuyến mãi tiếp theo" type="button">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="9 18 15 12 9 6"></polyline>
            </svg>
        </button>
    </div>

    <!-- Thanh chỉ số Dots / Pill -->
    <div class="promo-indicators" id="promoIndicators">
        <button class="promo-dot" data-index="0" aria-label="Khuyến mãi 1" type="button"></button>
        <button class="promo-dot active" data-index="1" aria-label="Khuyến mãi 2" type="button"></button>
        <button class="promo-dot" data-index="2" aria-label="Khuyến mãi 3" type="button"></button>
        <button class="promo-dot" data-index="3" aria-label="Khuyến mãi 4" type="button"></button>
        <button class="promo-dot" data-index="4" aria-label="Khuyến mãi 5" type="button"></button>
    </div>
</section>

<!-- HƯƠNG VỊ NỔI BẬT (THANH TRƯỢT NGANG GIỐNG PHẦN KHUYẾN MÃI) -->
<section class="container section category-carousel-section">
    <div class="category-header-row">
        <div>
            <p class="eyebrow"><?= icon('pizza', 'eyebrow-icon', 16) ?> Danh mục tuyển chọn</p>
            <h2>Hương vị nổi bật</h2>
        </div>
        <div class="category-nav-controls">
            <span class="category-hint-text">Vuốt hoặc bấm nút để khám phá</span>
            <div class="category-header-arrows">
                <button class="category-arrow-btn category-prev" id="catPrevBtn" aria-label="Danh mục trước" type="button">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="15 18 9 12 15 6"></polyline>
                    </svg>
                </button>
                <button class="category-arrow-btn category-next" id="catNextBtn" aria-label="Danh mục tiếp theo" type="button">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="9 18 15 12 9 6"></polyline>
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <!-- CAROUSEL WRAPPER WITH FLOATING ORANGE CHEVRONS (< >) -->
    <div class="category-carousel-wrapper">
        <!-- Nút tròn cam điều hướng bên trái (<) nổi trên mép trượt -->
        <button class="category-arrow-btn category-floating-prev" id="catFloatingPrevBtn" aria-label="Danh mục trước" type="button">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="15 18 9 12 15 6"></polyline>
            </svg>
        </button>

        <div class="category-slider-track" id="categoryTrack">
            <?php foreach ($categories as $index => $category): ?>
                <div class="category-slide" data-index="<?= $index ?>">
                    <a class="category-card-slide" href="<?= e(url('home', 'index', ['category_id' => $category['id']])) ?>#menu">
                        <div class="cat-card-img-wrap">
                            <img src="<?= e($category['image'] ?: 'img/JTPSD2ONPYISBHIP4CJ5HDW55A_01.webp') ?>" alt="<?= e($category['name']) ?>" loading="lazy">
                            <span class="cat-card-badge">Khám phá</span>
                        </div>
                        <div class="cat-card-content">
                            <strong class="cat-card-title"><?= e($category['name']) ?></strong>
                            <p class="cat-card-desc"><?= e($category['description'] ?: 'Thưởng thức hương vị ẩm thực Ý chuẩn vị hảo hạng') ?></p>
                            <div class="cat-card-action">
                                <span>Xem món ngon</span>
                                <?= icon('arrow-right', 'cat-card-arrow', 14) ?>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Nút tròn cam điều hướng bên phải (>) nổi trên mép trượt -->
        <button class="category-arrow-btn category-floating-next" id="catFloatingNextBtn" aria-label="Danh mục tiếp theo" type="button">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="9 18 15 12 9 6"></polyline>
            </svg>
        </button>
    </div>

    <!-- Thanh chỉ số Dots / Pill -->
    <div class="category-indicators" id="categoryIndicators">
        <?php foreach ($categories as $index => $category): ?>
            <button class="cat-dot <?= $index === 0 ? 'active' : '' ?>" data-index="<?= $index ?>" aria-label="Danh mục <?= $index + 1 ?>" type="button"></button>
        <?php endforeach; ?>
    </div>
</section>

<section id="menu" class="container section">
    <div class="section-heading">
        <div>
            <p class="eyebrow"><?= icon('sparkle', '', 14) ?> Thực đơn hôm nay</p>
            <h2>Món ngon đang bán</h2>
        </div>
        <form class="filter-form" method="get" action="index.php#menu">
            <input type="hidden" name="controller" value="home">
            <input type="hidden" name="action" value="index">
            <div class="search-input-wrap">
                <?= icon('search', 'search-icon', 18) ?>
                <input type="search" name="q" placeholder="Tìm pizza, gà rán, mì ý, đồ uống..." value="<?= e($keyword) ?>">
            </div>
            <select name="category_id">
                <option value="0">Tất cả danh mục</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?= e($category['id']) ?>" <?= (int) $categoryId === (int) $category['id'] ? 'selected' : '' ?>>
                        <?= e($category['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button class="btn btn-dark" type="submit">
                <?= icon('search', '', 16) ?>
                <span>Lọc</span>
            </button>
        </form>
    </div>

    <!-- QUICK CATEGORY PILLS BAR -->
    <div class="category-pills-bar">
        <a href="<?= e(url('home', 'index')) ?>#menu" class="category-pill-item <?= empty($categoryId) ? 'active' : '' ?>">
            <?= icon('pizza', '', 15) ?>
            <span>Tất cả món</span>
        </a>
        <?php foreach ($categories as $category): ?>
            <a href="<?= e(url('home', 'index', ['category_id' => $category['id']])) ?>#menu" 
               class="category-pill-item <?= (int) $categoryId === (int) $category['id'] ? 'active' : '' ?>">
                <span><?= e($category['name']) ?></span>
            </a>
        <?php endforeach; ?>
    </div>

    <?php if (empty($products)): ?>
        <div class="empty-state compact">
            <div class="empty-icon"><?= icon('package', '', 40) ?></div>
            <h3>Chưa có sản phẩm phù hợp</h3>
            <p>Hãy thử từ khóa hoặc danh mục khác.</p>
        </div>
    <?php else: ?>
        <div class="product-grid">
            <?php foreach ($products as $product): ?>
                <article class="product-card">
                    <a href="<?= e(url('product', 'detail', ['id' => $product['id']])) ?>" class="product-card-thumb-link">
                        <img src="<?= e($product['image'] ?: 'img/JTPSD2ONPYISBHIP4CJ5HDW55A_01.webp') ?>" alt="<?= e($product['name']) ?>" loading="lazy">
                    </a>
                    <div class="product-body">
                        <div class="product-card-top-row">
                            <span class="pill"><?= e($product['category_name'] ?? 'Món ngon') ?></span>
                            <?php $rInfo = $ratings[$product['id']] ?? null; ?>
                            <?php if ($rInfo && $rInfo['count'] > 0): ?>
                                <a href="<?= e(url('product', 'detail', ['id' => $product['id']])) ?>#reviews" class="card-star-badge" title="<?= $rInfo['count'] ?> lượt đánh giá">
                                    <?= icon('star', 'icon-star-badge', 13) ?>
                                    <span><?= number_format($rInfo['avg'], 1) ?></span>
                                    <span class="badge-count">(<?= $rInfo['count'] ?>)</span>
                                </a>
                            <?php else: ?>
                                <span class="card-star-badge new-item">
                                    <?= icon('sparkle', '', 12) ?>
                                    <span>Mới</span>
                                </span>
                            <?php endif; ?>
                        </div>
                        <h3><a href="<?= e(url('product', 'detail', ['id' => $product['id']])) ?>" title="<?= e($product['name']) ?>"><?= e($product['name']) ?></a></h3>
                        <p title="<?= e($product['description']) ?>"><?= e($product['description']) ?></p>
                        <div class="product-footer">
                            <form method="post" action="<?= e(url('cart', 'add')) ?>" class="product-card-form">
                                <input type="hidden" name="product_id" value="<?= e($product['id']) ?>">
                                <div class="card-footer-top-row">
                                    <div class="product-price-box">
                                        <span class="price-sublabel">Giá chỉ</span>
                                        <strong class="product-price" data-base-price="<?= (float)$product['price'] ?>"><?= money($product['price']) ?></strong>
                                    </div>
                                    <div class="card-size-wrapper">
                                        <select name="size" class="card-size-select" aria-label="Chọn kích thước" title="Chọn size (S, M, L, XL)">
                                            <option value="S">Size S (6")</option>
                                            <option value="M" selected>Size M (9")</option>
                                            <option value="L">Size L (12")</option>
                                            <option value="XL">Size XL (14")</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="card-footer-action-row">
                                    <div class="card-stepper-mini">
                                        <button type="button" class="card-step-btn minus" onclick="let inp=this.nextElementSibling; if(inp.value>1) inp.value--;" aria-label="Giảm số lượng">&minus;</button>
                                        <input class="card-qty-input" type="number" name="quantity" value="1" min="1" max="20" aria-label="Số lượng">
                                        <button type="button" class="card-step-btn plus" onclick="let inp=this.previousElementSibling; if(inp.value<20) inp.value++;" aria-label="Tăng số lượng">&plus;</button>
                                    </div>
                                    <button class="btn btn-primary btn-add-cart" type="submit" title="Thêm vào giỏ hàng">
                                        <?= icon('cart', '', 15) ?>
                                        <span>Thêm vào giỏ</span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const track = document.getElementById('promoTrack');
    const prevBtn = document.getElementById('promoPrevBtn');
    const nextBtn = document.getElementById('promoNextBtn');
    const dots = document.querySelectorAll('.promo-dot');
    const slides = document.querySelectorAll('.promo-slide');

    if (!track || slides.length === 0) return;

    // Khởi tạo vị trí banner 1 (Hẹn hò tiệc gà 99k, giống ảnh mẫu)
    let currentIndex = 1;
    let autoPlayTimer = null;
    let isUserInteracting = false;

    function updateActiveState(index) {
        currentIndex = index;
        dots.forEach((dot, idx) => {
            dot.classList.toggle('active', idx === index);
        });
        slides.forEach((slide, idx) => {
            slide.classList.toggle('is-active', idx === index);
        });
    }

    function scrollToSlide(index, smooth = true) {
        if (index < 0) index = slides.length - 1;
        if (index >= slides.length) index = 0;

        const slide = slides[index];
        if (!slide) return;

        // Căn banner mục tiêu chính xác ở giữa màn hình
        const targetLeft = slide.offsetLeft - (track.clientWidth - slide.offsetWidth) / 2;
        track.scrollTo({
            left: targetLeft,
            behavior: smooth ? 'smooth' : 'auto'
        });
        updateActiveState(index);
    }

    if (prevBtn) {
        prevBtn.addEventListener('click', function (e) {
            e.preventDefault();
            scrollToSlide(currentIndex - 1);
            resetAutoPlay();
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', function (e) {
            e.preventDefault();
            scrollToSlide(currentIndex + 1);
            resetAutoPlay();
        });
    }

    dots.forEach(dot => {
        dot.addEventListener('click', function () {
            const idx = parseInt(this.getAttribute('data-index'), 10);
            scrollToSlide(idx);
            resetAutoPlay();
        });
    });

    // Theo dõi thao tác vuốt cảm ứng hoặc cuộn ngang
    let scrollTimeout;
    track.addEventListener('scroll', function () {
        clearTimeout(scrollTimeout);
        scrollTimeout = setTimeout(function () {
            const trackCenter = track.scrollLeft + track.clientWidth / 2;
            let closestIndex = 0;
            let minDistance = Infinity;

            slides.forEach((slide, idx) => {
                const slideCenter = slide.offsetLeft + slide.offsetWidth / 2;
                const dist = Math.abs(trackCenter - slideCenter);
                if (dist < minDistance) {
                    minDistance = dist;
                    closestIndex = idx;
                }
            });

            if (closestIndex !== currentIndex) {
                updateActiveState(closestIndex);
            }
        }, 60);
    }, { passive: true });

    function startAutoPlay() {
        stopAutoPlay();
        autoPlayTimer = setInterval(function () {
            if (!isUserInteracting) {
                scrollToSlide(currentIndex + 1);
            }
        }, 5000);
    }

    function stopAutoPlay() {
        if (autoPlayTimer) {
            clearInterval(autoPlayTimer);
            autoPlayTimer = null;
        }
    }

    function resetAutoPlay() {
        stopAutoPlay();
        startAutoPlay();
    }

    track.addEventListener('mouseenter', function () { isUserInteracting = true; });
    track.addEventListener('mouseleave', function () { isUserInteracting = false; });
    track.addEventListener('touchstart', function () { isUserInteracting = true; }, { passive: true });
    track.addEventListener('touchend', function () {
        setTimeout(function () { isUserInteracting = false; }, 2000);
    }, { passive: true });

    // Khởi tạo canh giữa banner 1 ngay khi tải trang
    setTimeout(function () {
        scrollToSlide(1, false);
        startAutoPlay();
    }, 120);

    // Cập nhật lại vị trí căn giữa khi thay đổi kích thước cửa sổ
    window.addEventListener('resize', function () {
        scrollToSlide(currentIndex, false);
    });

    // === CATEGORY CAROUSEL LOGIC (HƯƠNG VỊ NỔI BẬT) ===
    const catTrack = document.getElementById('categoryTrack');
    const catPrevBtn = document.getElementById('catPrevBtn');
    const catNextBtn = document.getElementById('catNextBtn');
    const catFloatingPrevBtn = document.getElementById('catFloatingPrevBtn');
    const catFloatingNextBtn = document.getElementById('catFloatingNextBtn');
    const catDots = document.querySelectorAll('.cat-dot');
    const catSlides = document.querySelectorAll('.category-slide');

    if (catTrack && catSlides.length > 0) {
        function getSlideScrollAmount() {
            const firstSlide = catSlides[0];
            const slideWidth = firstSlide ? firstSlide.offsetWidth : 260;
            return slideWidth + 20; // slide width + gap
        }

        function scrollCategoryBy(direction) {
            const amount = getSlideScrollAmount() * direction;
            catTrack.scrollBy({ left: amount, behavior: 'smooth' });
        }

        function scrollToCatIndex(index) {
            const slide = catSlides[index];
            if (slide) {
                catTrack.scrollTo({ left: slide.offsetLeft - catTrack.offsetLeft, behavior: 'smooth' });
            }
        }

        if (catPrevBtn) catPrevBtn.addEventListener('click', () => scrollCategoryBy(-1));
        if (catNextBtn) catNextBtn.addEventListener('click', () => scrollCategoryBy(1));
        if (catFloatingPrevBtn) catFloatingPrevBtn.addEventListener('click', () => scrollCategoryBy(-1));
        if (catFloatingNextBtn) catFloatingNextBtn.addEventListener('click', () => scrollCategoryBy(1));

        catDots.forEach(dot => {
            dot.addEventListener('click', function() {
                const idx = parseInt(this.getAttribute('data-index'), 10);
                scrollToCatIndex(idx);
            });
        });

        let catScrollTimeout;
        catTrack.addEventListener('scroll', function() {
            clearTimeout(catScrollTimeout);
            catScrollTimeout = setTimeout(function() {
                const scrollLeft = catTrack.scrollLeft;
                let activeIdx = 0;
                let minDiff = Infinity;
                catSlides.forEach((slide, idx) => {
                    const diff = Math.abs(slide.offsetLeft - catTrack.offsetLeft - scrollLeft);
                    if (diff < minDiff) {
                        minDiff = diff;
                        activeIdx = idx;
                    }
                });
                catDots.forEach((dot, idx) => {
                    dot.classList.toggle('active', idx === activeIdx);
                });
            }, 60);
        }, { passive: true });
    }

    // === HERO VIDEO CONTROLS ===
    const heroVideo = document.getElementById('heroVideo');
    const heroVideoToggleBtn = document.getElementById('heroVideoToggleBtn');
    const heroVideoMuteBtn = document.getElementById('heroVideoMuteBtn');
    const pauseIcon = document.getElementById('heroVideoPauseIcon');
    const playIcon = document.getElementById('heroVideoPlayIcon');
    const mutedIcon = document.getElementById('heroVideoMutedIcon');
    const unmutedIcon = document.getElementById('heroVideoUnmutedIcon');

    if (heroVideo && heroVideoToggleBtn) {
        heroVideoToggleBtn.addEventListener('click', function() {
            if (heroVideo.paused) {
                heroVideo.play().then(() => {
                    if (pauseIcon) pauseIcon.style.display = 'inline-flex';
                    if (playIcon) playIcon.style.display = 'none';
                }).catch(e => console.log('Video play error:', e));
            } else {
                heroVideo.pause();
                if (pauseIcon) pauseIcon.style.display = 'none';
                if (playIcon) playIcon.style.display = 'inline-flex';
            }
        });
    }

    if (heroVideo && heroVideoMuteBtn) {
        heroVideoMuteBtn.addEventListener('click', function() {
            heroVideo.muted = !heroVideo.muted;
            if (heroVideo.muted) {
                if (mutedIcon) mutedIcon.style.display = 'inline-flex';
                if (unmutedIcon) unmutedIcon.style.display = 'none';
            } else {
                if (mutedIcon) mutedIcon.style.display = 'none';
                if (unmutedIcon) unmutedIcon.style.display = 'inline-flex';
            }
        });
    }

    // === QUICK SIZE PRICE UPDATE ON PRODUCT CARDS ===
    const sizeFactors = { 'S': 0.8, 'M': 1.0, 'L': 1.3, 'XL': 1.6 };
    document.querySelectorAll('.card-size-select').forEach(function(select) {
        select.addEventListener('change', function() {
            const form = this.closest('.product-card-form');
            if (!form) return;
            const priceEl = form.querySelector('.product-price');
            if (!priceEl) return;
            const basePrice = parseFloat(priceEl.dataset.basePrice || 0);
            const factor = sizeFactors[this.value] || 1.0;
            const finalPrice = Math.round((basePrice * factor) / 1000) * 1000;
            priceEl.textContent = new Intl.NumberFormat('vi-VN').format(finalPrice) + ' đ';
        });
    });
});
</script>
